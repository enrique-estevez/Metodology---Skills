---
name: accenture-pptx
description: Generate Accenture-style executive client presentations (.pptx). Use when the user asks to build, create, reformat, or generate an Accenture deck, slides, presentation, board deck, executive deck, exec presentation, strategy deck, or proposal deck. Combines content-first iteration in HTML + markdown with a final python-pptx build using brand-disciplined helpers. Triggers on: "build a deck", "create slides", "Accenture presentation", "executive deck", "board deck", "reformat pptx", "PPT", "PowerPoint", "pptx".
---

# Accenture Frontier Visual Slide Generation Skill

Generate consultant-grade Accenture presentations from sparse prompts using a three-phase workflow:

```
Phase 1 — Content brief + HTML mockups          (markdown + browser; cheap iteration)
   ↓
Phase 2 — Slide-by-slide HTML refinement        (optional, when visual details need tuning)
   ↓
Phase 3 — pptx build                            (python-pptx using lib/ helpers)
```

The trap this avoids: iterating content and visuals simultaneously inside pptx code — slow, expensive, and the wrong abstraction. Lock content in markdown, lock design in HTML, then commit to pptx.

## Operating contract (always applies)

1. **Plan the argument first.** Write the message map (`reference/planning.md` §1) before designing any slide — governing question, decision, context, answer, argument beats, options, caveats, conditions for value.
2. **Story before shapes.** Every slide has a one-sentence assertion headline before any object is placed.
3. **Visual choice before shape placement.** Decide the right graphic form, then build. **If your first instinct is a row of equal cards or text panels → STOP.** `[WORKHORSE]` is the Phase 3 default; `[HERO]` is only assigned when a Phase 2 treatment produces a genuinely curvilinear or organic form — tag it at the Phase 2 lock, not in Phase 1.
4. **WORKHORSE is the default — native shapes + connectors.** Architecture boards, roadmaps, process flows, swimlanes, matrices → always `[WORKHORSE]`. `[HERO]` is only tagged at a Phase 2 lock when a treatment (typically Content-native or "Describe what you want") produces a genuinely curvilinear or organic form that rectangles cannot build. Fewer than 1 in 5 slides should ever be `[HERO]`.
5. **Each non-appendix slide needs a primary graphic object** — chart, matrix, map, curve, loop, bridge, ladder, blueprint, etc.
6. **Variation is mandatory.** Distinct silhouettes across the deck; no two adjacent slides share a silhouette.
7. **No output before QA.** Run the four-lens review (`reference/qa.md`) on every slide — Build · Visual/Aesthetic · Story/Structure · Consulting Rigor — and correct per §19 before reporting done. Apply the title-only test and ship gate.

---

## Archetype library — 33 ready-to-clone HTMLs

All 33 archetypes ship as HTML templates in `scaffold/archetypes/`. Browse the full visual catalog at `scaffold/archetypes-catalog.html` — open in browser for at-a-glance comparison.

### Quick-reference routing

| Message type | Default archetype | Helper / template |
|---|---|---|
| **Cover / opener** | Editorial cover split (§6.26) · Hero signal wall (§6.27) | `editorial-cover-split.html` · `hero-signal-wall.html` |
| **Shift / before-vs-after** | Transition bridge (§6.1) | **`transition_bridge`** · `transition-bridge.html` |
| **Value at stake / economics** | Indexed trajectory (§6.2) · Evidence mosaic (§6.3) · Value bridge (§6.19) | `indexed-trajectory-chart.html` · `evidence-mosaic.html` · `value-bridge.html` |
| **Why now / proof** | Premium benchmark field (§6.28) · Layered evidence wall (§6.22) · Signal-to-action (§6.24) | `premium-benchmark-field.html` · `layered-evidence-wall.html` · `signal-to-action.html` |
| **Where to play / portfolio** | 2×2 portfolio (§6.4) · Spotlight decision field (§6.30) | **`portfolio_2x2`** · `portfolio-2x2.html` · `spotlight-decision-field.html` |
| **Op model / capabilities (escalating)** | Layered control stack (§6.7) · Wedge spectrum (§6.5) · Staircase (§6.11) | **`layered_stack`** · `layered-stack.html` · `wedge-spectrum.html` · `staircase-maturity.html` |
| **How it works / operating loop** | Closed-loop orbit (§6.6) · Command-center hub (§6.14) | `closed-loop-orbit.html` · `command-center-hub.html` |
| **Path forward / roadmap** | Transformation runway (§6.8) · Insight ribbon (§6.15) | `transformation-runway.html` · `insight-ribbon.html` |
| **Workflow / pipeline / handoff** | Synchronized swimlanes (§6.16) | **`swimlane_row`** · `swimlanes.html` |
| **Recommendation by category** | Recommendation stack (§6.25) | `recommendation-stack.html` |
| **Decision logic** | Decision tree (§6.9) | `decision-tree.html` |
| **Capability strategy** | House model (§6.10 — use with care) · Pyramid (§6.23 — sparingly) | `house-model.html` · `pyramid.html` |
| **Cross-functional / ecosystem** | Ecosystem map (§6.13) · Multi-rail operating poster (§6.31) · Chord/flow (§6.21 — exec-readability check) | `ecosystem-map.html` · `multi-rail-poster.html` · `chord-flow.html` |
| **Target-state architecture** | Blueprint board (§6.12) | `blueprint-board.html` |
| **Comparison across dimensions** | Radar (§6.20 — sparingly) | `radar.html` |
| **Case study / credibility** | Split case-study field (§6.18) | `split-case-study.html` |
| **Annotated evidence** | Annotated artifact (§6.17) · Annotated panorama (§6.29) | `annotated-artifact.html` · `annotated-panorama.html` |
| **Closing / discussion** | Premium closing discussion (§6.32) · Elegant thank-you (§6.33) | `premium-closing-discussion.html` · `elegant-thank-you.html` |

If you reach for an equal-card grid, **stop** — re-route through this table first.

### Novel-design exploration

For each slide in Phase 1, propose **3 archetype candidates**:
1. The canonical archetype from the library above (highest credibility, brand-safe)
2. A second canonical alternative with different visual logic (the trade-off option)
3. **A novel layout** if and only if a fresh approach genuinely fits the message better than what's in the library

**Rules for novel proposals**:
- Must obey all brand discipline: Graphik typography, the 11-token palette, squares-not-circles, light-mode default, purple-as-signal
- Must have a clear primary graphic object (no abstract collages)
- Must pass the §18 QA scorecard (graphic existence, asset fit, premium finish all ≥ 4)
- Must be distinct from neighboring slides' silhouettes
- Flag clearly as "novel — extends the library" in the brief.html mockup card so the user can opt in or fall back to canonical

When in doubt, prefer canonical. Novel is the **third** candidate, not the default. Decks that consistently use the canonical 33 read as on-pattern; decks that go novel on every slide read as experimental.

---

## Workflow — three phases

### Phase 1 — Content brief + HTML mockups (always)

Goal: lock story, copy, and chosen archetype per slide **before any pptx work**.

Set up workspace (default: `Downloads/<deck-name>-html/`) by copying from `scaffold/`:
```
<deck-name>-html/
  style.css                       brand discipline (fonts, palette, motif)
  brief.md                        editable content brief
  brief.html                      visual rendering of brief.md with archetype mockups
  render-brief.ps1                Chrome-headless → PNG of brief.html
  fonts/                          Graphik TTFs
```

**Brief.md structure** — fill in `scaffold/brief.md.template`:
- Deck-level table: audience, intent, mode, count, story arc, motif, takeaway
- Per slide: role · headline · strapline · argument · evidence/support · 3 archetype candidates (2 canonical + 1 novel where applicable)
- Open questions block

**Brief.html structure** — see `scaffold/brief.html.template`. Renders:
- Deck summary table + brand palette strip + takeaway pull-quote
- Per slide: same content as brief.md, plus **large inline SVG mockups** (full card width, 16:9 aspect ratio ≈ 440×250px) of each archetype candidate — sized to be discriminable without any user interaction
- Recommended archetype outlined in purple; novel archetype marked with `data-novel="true"` badge and dashed border
- Open questions as numbered cards

If the user wants to see an archetype at full slide scale (1280×720), emit `scaffold/archetypes/<name>.html` as a separate artifact (Claude.ai) or open it in a browser (Claude Code) — do *not* rely on clickable links inside the brief artifact, those don't navigate reliably.

**Iteration loop**: edit `brief.md` text-only until story reads right. Re-render `brief.html` after big content changes. Each cycle ~5 seconds.

**Locking choices — tell the user how to pick.** Once the brief is in front of the user, explain how to lock one archetype per slide using a compact per-slide shorthand — e.g. *"Slide 1 — A, Slide 2 — B, Slide 3 — needs changes."* If a slide's three options all work, they just name the letter; for any slide they're not happy with, they say "needs changes" (or describe what's off) and you open **deeper design mode** for that slide. Every slide locked → recap and head to the pre-build confirmation; any slide flagged → deeper design mode. Never say "Phase 2" to the user — call it "deeper design mode."

**Phase 1 exits when**: each slide has one locked archetype, headlines are final, tone is normalized, axis/data choices are confirmed.

**After all slides are locked, always offer the two-path choice explicitly** — even when every slide locked cleanly on the first pass:
> *"All slides locked. You can:*
> *· Say **'build the pptx'** to go straight to Phase 3 — the deck builds with the chosen archetypes.*
> *· Say **'deeper design mode for slide N'** (or list several slides) to explore a more distinctive visual direction. You'll get six treatment options: **Typographic · Quantitative · Compositional · Imagistic · Content-native · Describe what you want** — each produces a unique visual identity, not an adaptation of a standard archetype."*

Users who skip Phase 2 don't know it exists — always surface this choice at Phase 1 exit.

### Phase 2 — Deeper design mode (OPTIONAL; internal name)

> Never say "Phase 2" to the user — call it **deeper design mode**.

Enter deeper design mode only for the slides the user flagged as not-yet-right when locking choices (see "Locking choices" in Phase 1). Slides already locked to an option (A / B / C) need no deeper pass.

**On entering deeper design mode, ask the branch question first** — for each flagged slide:

> "For slide N — tweak the current direction (keep the same overall mood, just adjust details), or try something completely new (a different design language)?"

- **Tweak / same mood** → Phase 2a (refine the chosen archetype). Lock the slide once the user is happy.
- **Something completely new** → Phase 2b (treatments).

When every flagged slide is resolved and all choices are locked, recap the line-up and move to the pre-build confirmation before Phase 3.

#### Phase 2a — Refine the chosen archetype

Copy archetype templates from `scaffold/archetypes/` (one per slide) and fill in locked content. Iterate via `render.ps1` (renders 4-up strip in ~15s). The user redlines visual details ("more whitespace", "swap dot positions", etc.) until the slide is locked. When the slide is shown in the Claude.ai conversation panel, wrap its 1280×720 `.slide` in the scale-to-fit frame (`scaffold/slide.html.template`) so the full canvas displays without clipping (rule 9).

#### Phase 2b — Treatments (design exploration)

Reached when the user picks **"something completely new"** for a slide (or otherwise signals the archetype direction isn't landing — "none of these feel fresh", "make it less standard").

Offer the **Treatments menu** (6 options) from `scaffold/treatments/`:

| # | Treatment | Hero (dominant attention vector) | One-line characterization |
|---|---|---|---|
| 1 | **Typographic**   | Language      | Large display type, magazine rhythm (FT / NYT / MIT Tech Review feature pages) |
| 2 | **Quantitative**  | Data          | Tufte-style info-graphic; small multiples + sparklines + dense annotation |
| 3 | **Compositional** | Orchestration | Multi-panel editorial board (Bloomberg explainer / Pentagram annual report) |
| 4 | **Imagistic**     | Image         | Full-bleed visual field with overlay structure; image carries the page |
| 5 | **Content-native** | Structure | Reason from what this content *is* structurally (flow / hierarchy / comparison / system / magnitude) to design a bespoke native exhibit from first principles — no template, no style archetype |
| 6 | **Describe what you want** | Your reference | No scaffold — user describes the design; Claude generates fresh within brand discipline |

Show the user `scaffold/treatments/treatments-catalog.html` (or list the six options inline). The user picks one for the affected slide(s).

**For options 1–4**: read the corresponding anchor HTML (`scaffold/treatments/<name>.html`) as **inspiration**, not a template. Generate a fresh slide HTML in that treatment's spirit with the user's locked Phase 1 content filled in.

**For option 5 (Content-native)**: no anchor HTML — reason from first principles. Ask: what is this content structurally showing? Classify it: is it a **flow** (A→B→C sequence), a **hierarchy** (nested levels / escalating tiers), a **comparison** (A vs B vs C side by side), a **system** (interdependent parts with relationships), or a **magnitude** (quantities / scale)? Then ask: what geometric configuration makes that structural type most legible — what shapes, what spatial relationships, what emphasis? Design and build the HTML from that configuration using brand-disciplined native shapes. No template, no style reference. The form should be purpose-built for this specific content, not adapted from anything. Run a stricter self-QA pass (graphic existence and asset fit ≥4) before showing.

**For option 6 (Describe what you want)**: ask the user to describe the design they're imagining — reference an external deck/page, name a feel, or describe layout/typography moves they like. Generate from scratch with no anchor; obey brand discipline strictly; run a stricter self-QA pass before showing.

**Non-negotiable brand discipline applies to every treatment**:
- Accenture palette only (11 tokens)
- Graphik typography
- Squares-not-circles
- Light-mode default (dark surfaces only on hero / imagistic / section dividers)
- 16:9 widescreen, canonical bands
- Primary graphic object present
- Pass §18 QA scorecard (graphic existence ≥4, asset fit ≥4, premium finish ≥4) before showing

If the user accepts a treatment, ask: *"Apply this treatment to other slides, or keep it on slide N only?"* — don't auto-propagate.

**Assigning `[HERO]` at the Phase 2 lock.** If the locked treatment (typically Content-native or "Describe what you want") produced a genuinely curvilinear or organic form — value curves, diverging trajectories, annotated maps — tag that slide `[HERO]` when locking it. All other Phase 2 locks (treatments 1–4 and Phase 2a refinements) remain `[WORKHORSE]`. The tag travels to Phase 3 with no re-decision.

See `scaffold/treatments/README.md` for the extension contract (how to add / modify / remove treatments).

**Phase 2 exits when**: each slide-N.html renders without geometry issues and matches the locked design (whether refined archetype or treatment-generated).

### Phase 3 — pptx build

**Pre-build confirmation (required).** Before building, post a quick per-slide recap of the locked choices and ask the user to confirm — e.g. *"Slide 1 — Editorial cover split · Slide 2 — Indexed trajectory chart · Slide 3 — Closed-loop orbit (reworked in deeper design mode) · … Shall I build the .pptx?"* Build only after the user confirms; if they want a change, send that slide back to locking / deeper design mode and re-confirm.

Use the helpers in `lib/acn_pptx_utils.py`:

```python
from lib.acn_pptx_utils import (
    new_deck, add_blank, header, footer,
    # core archetype builders
    transition_bridge, layered_stack, swimlane_row, portfolio_2x2,
    # extended archetype builders (use these before building from primitives)
    editorial_cover_split, hero_signal_wall, transformation_runway,
    blueprint_board, recommendation_stack, closed_loop_orbit, evidence_mosaic,
    PURPLE_PRIMARY, PURPLE_DEEP, PURPLE_PLUM, LAVENDER, WHITE, ...
)

prs = new_deck()
s = add_blank(prs)
header(s, "Headline", "Strapline", utility="Section · context")
layered_stack(s, x=0.42, y=1.85, w=12.50, h=5.20, tiers=[...])
footer(s, page_num=1, total=4)
prs.save(out_path)
```

For archetypes without a Python helper, build inline using primitives (`add_rect`, `add_text`, `add_line`, `add_oval`, `add_chip`). Match the proportions from the slide HTML.

**Hero exhibits — only for slides tagged `[HERO]` at a Phase 2 lock. If no slide was tagged `[HERO]`, skip this section entirely — all slides default to `[WORKHORSE]`. Do not re-evaluate whether a slide should be a hero here.**

```python
from lib.acn_pptx_utils import rasterize_svg, add_image, hero_label_xy, add_text, PURPLE_PLUM

# 1. Author the SVG at the exact aspect ratio of the pptx rectangle it fills.
#    Marks only — NO <text> elements. All labels go as native text afterward.
svg = """<svg xmlns="http://www.w3.org/2000/svg" width="1234" height="500">
  <defs>
    <linearGradient id="g" x1="0" y1="1" x2="1" y2="0">
      <stop offset="0" stop-color="#460073"/>
      <stop offset="1" stop-color="#A100FF"/>
    </linearGradient>
  </defs>
  <path d="M80,420 C400,390 600,200 900,150 S1180,60 1220,50"
        fill="none" stroke="url(#g)" stroke-width="14" stroke-linecap="round"/>
  <path d="M80,440 C400,430 600,350 900,330 S1180,320 1220,318" fill="#E6DCFF"/>
  <circle cx="900" cy="150" r="14" fill="#A100FF"/>
</svg>"""

# 2. Rasterize at ≥2x (cairosvg required: pip install cairosvg).
rasterize_svg(svg, "hero_slide3.png", width=2560)

# 3. Place as ONE image — never multiple fragments for one exhibit.
img_x, img_y, img_w, img_h = 0.5, 1.5, 12.33, 5.0
add_image(slide, "hero_slide3.png", img_x, img_y, img_w, img_h)

# 4. Every label is native text at its SVG anchor — never baked in.
lx, ly = hero_label_xy(img_x, img_y, img_w, img_h, cx_px=900, cy_px=150,
                        svg_w=1234, svg_h=500)
add_text(slide, lx - 0.9, ly - 0.15, 1.8, 0.30, "Early movers compound",
         size=11, bold=True, color=PURPLE_PLUM)
```

See `reference/design-system.md` §14–§19 for the full two-mode system, job-organized visual palette, and hero SVG pipeline rules. `rasterize_svg`, `add_image`, and `hero_label_xy` are in `lib/acn_pptx_utils.py`.

**Verify geometry** (math-only, before any render):
```bash
python lib/verify_geometry.py path/to/deck.pptx
```

**Render preview strip** (one PNG, not N):
```bash
python lib/render_strip.py path/to/deck.pptx
```

**QA** — read `reference/qa.md`. Run the single structured checklist (Build · Visual/Aesthetic · Story/Structure · Consulting Rigor) in one pass, score each slide 1–5 across A–G, and apply §19 correction protocol for any failures. Apply the ship gate before declaring done. **Maximum 2 fix-and-re-render iterations.** If defects remain after two rounds, surface the issue to the user with the §19 correction protocol and ask whether to ship as-is, escalate to a structural rebuild, or revisit Phase 2 visuals.

**Headline reflow budget (Build lens)** — headline box height must be `font_pt × 2.4 / 72` inches (~0.76" at 22pt, ~1.0" at 30pt). Strapline must start at or after `headline_y + that height`. `GEOMETRY PASS` is not sufficient for headline/strapline pairs; the static checker cannot model text reflow.

**Mandatory headline-band visual check (Visual lens)** — on every render-strip review, explicitly confirm the headline does not collide with the strapline. This is the most common silent defect; the geometry checker cannot catch it.

---

## Claude.ai chat validation (artifact-driven)

When this skill is used in **Claude.ai** (web/desktop with artifact rendering), prefer in-chat HTML artifacts over local renders for Phase 1 and Phase 2. Both the Phase 1 brief and every Phase 2 slide must build **live, top-to-bottom in the conversation panel** — not appear all at once. The rules below make that reliable.

#### Authoring rules for live-streaming HTML (Phase 1 brief + every Phase 2 slide)

1. **Render path** — use the inline streaming HTML render only (the path that paints token-by-token in the conversation panel). Never dump the HTML into a code block, and never write the viewable version to a file and then re-open it.
2. **Source order for early paint** — short `<style>` first → visible DOM in reading order (header → slide 1 block → slide 2 block …) → hidden expand panels → no `<script>`. Use pure CSS; if a script is truly unavoidable, put it last.
3. **Flat fills only** in anything that streams (solid hex or `fill-opacity`). No gradients, box-shadows, blur, or glow on streamed structure — they flash during streaming DOM diffs. A solid tinted background on the expand overlay is fine because it only appears after a click.
4. **Self-contained** — no external font/script fetches that block first paint. Use `"Graphik","Inter","Helvetica Neue",system-ui,sans-serif`.
5. **Minimum 11px font-size** for all HTML chrome (labels, badges, captions). SVG text inside slide mockups is exempt (scaled artwork, not chrome).
6. **Click-to-expand modal must be IN-FLOW, never `position:fixed`:**
   - Toggle: `.ov{display:none}` / `.ov:target{display:flex}`
   - Overlay: `position:relative; min-height:~460px; align-items:center; justify-content:center;` + solid tinted background. It sits in normal flow and contributes height via `min-height`, so the render frame can't collapse. **Do not** use `position:fixed` (it collapses the streaming render frame).
   - Backdrop: `<a class="ovbd">` with `position:absolute; inset:0` INSIDE the relatively-positioned overlay (absolute is safe here; only fixed breaks it).
   - Inner card: `position:relative; z-index:1` above the backdrop, holding a duplicated copy of the SVG so it scales up cleanly.
7. **Overlay placement = adjacent to its slide** — place each slide's expand panels immediately AFTER that slide's block, NOT batched at the end of the document. A pure-CSS `:target` panel opens at its DOM position; batching them at the end makes an early slide's panel open below later slides.
8. **Close target = owning slide** — backdrop and × links point to the owning slide's anchor (e.g. `#s1`, `#s2` — give each slide block an id), so closing returns the reader to that slide rather than the document top.
9. **Scale-to-fit frame for fixed-geometry slides.** Any fixed-geometry slide (the 1280×720 `.slide` canvas — every Phase 2 slide) must be wrapped in a scale-to-fit frame so the full canvas displays inside the conversation panel without horizontal clipping: `aspect-ratio: 1280/720` + `container-type: inline-size` on the outer `.slide-frame`, and `transform: scale(calc(100cqw / 1280px))` on the inner `.slide-scale` (markup order `.slide-frame > .slide-scale > .slide`). The slide internals are untouched — same fonts, grid, and px geometry that feeds the pptx build; only display size changes, and at a panel ≥1280px wide the factor is 1.0. SVG silhouette mockups in the brief already scale and don't need the frame. `scaffold/slide.html.template` encodes the pattern.

**Net invariant:** every Phase 1 brief and Phase 2 slide must render via the inline streaming path · order source for early paint · use flat fills · be self-contained · use an in-flow (`:target`, `min-height`) modal placed adjacent to its slide with close links targeting that slide · wrap fixed-geometry (1280×720) slides in the scale-to-fit frame. `scaffold/brief.html.template` (brief) and `scaffold/slide.html.template` (Phase 2 slide) encode the exact CSS + HTML pattern.

**Phase 1 artifact flow**:
1. Render `brief.html` through the **inline streaming HTML render** (paints token-by-token in the conversation panel), not written to disk and re-opened. Self-contained CSS, no external fonts — use the `Graphik → Inter → Helvetica Neue → system-ui` fallback chain. Follow the authoring rules above (early-paint source order, flat fills, in-flow click-to-expand modal).
2. User sees the brief build live in the conversation
3. User redlines in the chat or paste-edits the markdown
4. Re-emit through the same streaming render with changes

In the interactive brief, each archetype mockup must carry a **persistent, always-visible "↗ Click to expand" label** (bottom-right, ≥11px, *not* `:hover`-gated) so the user discovers the click-to-enlarge — see `scaffold/brief.html.template` (`.zoom-hint`). After the brief renders, explain the **locking shorthand** (e.g. *"Slide 1 — A, Slide 2 — B, Slide 3 — needs changes"*) as described in Phase 1's "Locking choices."

**Phase 2 artifact flow**:
1. For each slide, emit a separate `slide-N.html` — rendered through the inline streaming HTML render and following the authoring rules above (early-paint order, flat fills, self-contained, in-flow modal)
2. User sees each slide build live, can request specific tweaks
3. Re-emit the affected slide only (not all four)

**Phase 3 stays local**: Claude.ai cannot produce .pptx files. After Phase 2 sign-off, emit the Python build script as a code artifact. The user runs it locally (`python build.py`) and uses `lib/verify_geometry.py` + `lib/render_strip.py` for QA.

**Font handling in Claude.ai artifacts**: since Graphik TTFs cannot be loaded from local disk in a chat artifact, use this fallback chain in artifact CSS:
```css
font-family: "Graphik", "Inter", "Helvetica Neue", system-ui, sans-serif;
```
The visual fidelity will be ~90% of Graphik — close enough for sign-off, and a perfect match once the user runs Phase 3 locally with real Graphik installed.

### Read on demand
- `reference/planning.md` — sparse-prompt protocol + design brief fields (Phase 1)
- `reference/routing.md` — full §5–§6 routing engine + archetype library
- `reference/design-system.md` — modes, geometry, typography, color, families
- `reference/mandates.md` — type-specific hard fails + anti-generic rules + quotas
- `reference/qa.md` — scorecard + correction protocol + acceptance (Phase 3)
- `reference/topic-defaults.md` — motif menu, beautification, AI/agentic defaults

---

## Reformatting an existing .pptx

For reformat tasks, the workflow starts with two routing questions — a **design dial** (how much the layout changes) and, for redesigns, a **data dial** (how much content survives).

### Phase 0 — Ask the user at the start (two dials)

After inspecting the source (`python lib/inspect_pptx.py source.pptx`), **stop and ask** before doing anything else. A reformat has two independent dials: **design** (how much the layout changes) and **data** (how much content survives).

**Question 1 — design dial:**

> "How do you want this reformat to work?
>
> **Re-brand only.** Keep every source layout exactly as-is and just restyle to Accenture brand — Graphik, the purple palette, the utility/headline/strapline/footer band system, squares-not-circles. No content moves, no layout changes. Fastest, lowest risk, fully lossless.
>
> **Redesign with the design system.** Per slide, I'll show two options side by side — a **Faithful** re-brand (your layout, on-brand, all data kept) and an **Upgraded** design-system archetype — and you pick per slide. Higher upside; you stay in control of every slide.
>
> **Design-first rebuild.** Carry over only your deck's **key messages and narrative** and rebuild it fresh: a clean, fully-designed deck that tells the same story, with labeled placeholders where your data goes — you add the numbers back afterward. This runs as **new-deck creation** seeded by your narrative, *not* a slide-by-slide reformat; the source's detailed data is not carried over."

If the user picks **Re-brand only** → run the Re-brand-only path (below) and you're done; skip Question 2. If they pick **Design-first rebuild** → see that section below; Question 2 does not apply (it's narrative-only by definition).

**Question 2 — data dial (only for Redesign): how should content be treated when a slide moves to a cleaner layout?**

> "When a slide upgrades to a new design-system layout, how should I treat its content?
>
> **Preserve everything (lossless).** Keep 100% — I'll reach for denser archetypes and split crowded slides into multiple clean ones rather than drop anything. Best when every number matters; trade-off is more slides.
>
> **Best fit (minimal loss) — recommended.** Keep everything that fits cleanly; move borderline detail to speaker notes or an appendix; drop only true clutter. The pragmatic middle.
>
> **Distill to the message.** Keep each slide's core assertion and the evidence that proves it, design cleanly around that, and park the rest in notes / appendix. Turns a dense working deck into an executive story — you confirm what counts as 'critical' in the brief before I build."

Question 2 sets a **global default**, overridable per slide during review. **Default is Best fit** if the user is unsure. Do not auto-choose either question — wait for the user.

### Re-brand only (no layout changes)

Goal: re-skin the source pptx with Accenture brand discipline while preserving every layout decision the source already made. No archetype substitutions, no content moves — fully lossless. (This is the whole job when the user picks "Re-brand only" in Question 1; it is also exactly what the **Faithful** column produces per slide in Redesign.)

**What to apply, per source slide**:
1. **Fonts**: replace every text run's font with Graphik (Semibold for headlines/emphasis, Regular for body)
2. **Colors**: map every fill / outline / text color to the nearest Accenture palette token (use a nearest-color helper — `PURPLE_PRIMARY`, `PURPLE_DEEP`, `PURPLE_PLUM`, `LAVENDER`, `LAVENDER_2`, `WHITE`, `NEUTRAL_LIGHT`, `NEUTRAL_MID`, `DIVIDER`, `LABEL_GRAY`, `BLACK`). After remapping, enforce a **contrast check** on every text run against its shape's final fill: if the fill maps to a light token (`WHITE`, `NEUTRAL_LIGHT`, `LAVENDER`, `LAVENDER_2`, `DIVIDER`) the text must be dark (`BLACK` / `PURPLE_PLUM`); if the fill maps to a dark token (`PURPLE_PLUM`, `PURPLE_DEEP`, `BLACK`) the text must be `WHITE`. Never remap fill and text independently without re-checking the pairing — preserve the source's original contrast direction, so text that was legible on its fill stays legible. And when a source fill carries **categorical / legend meaning** (it appears in a legend or encodes a data series), preserve the distinction between categories after remapping — don't collapse two distinct source colours onto the same token; if the palette can't hold the distinction, keep one as a semantic colour (as with the red/amber/green redundancy scale).
3. **Band system**: ensure each slide has the utility/headline/strapline/footer bands per the canonical anchors in `reference/design-system.md`. Insert missing bands; leave existing content in place.
4. **Squares not circles**: replace ovals/circles used as dots, badges, callout markers, or accent shapes with squares. Keep ovals only for genuine "people" icons or true Venn diagrams.
5. **Logo**: if the source has a placeholder/competitor logo, replace with Accenture wordmark; if it has a client logo, leave it
6. **Slide size**: convert to `13.333 × 7.5` inches (16:9 widescreen) if not already

**Build approach**: write a `build_convert.py` that loads the source pptx via `python-pptx`, walks each slide's shapes, applies the rules above in place. Do NOT use the `lib/acn_pptx_utils.py` archetype builders here — those build from scratch. Re-brand only restyles existing shapes.

Output: `<source-name>-acn.pptx`. Run `python lib/verify_geometry.py` and `python lib/render_strip.py` for QA. Deliver to user.

### Redesign — per-slide Faithful vs Upgraded (with a data treatment)

Goal: per slide, let the user keep a **Faithful** on-brand re-brand or accept an **Upgraded** design-system archetype. Two dials: the **design** choice is per slide (Faithful vs Upgraded); the **data** choice is the global default from Phase 0 Question 2 (Preserve / Best fit / Distill) and governs how content is handled on the Upgraded layout. Faithful is always lossless; the data treatment only bites on Upgraded.

**Render path.** In **Claude Code**, the comparison brief is `brief.html` in the local workspace, opened in a browser / rendered to PNG (the steps below). In **Claude.ai**, it must instead paint through the **inline streaming HTML render** per the "Claude.ai chat validation" authoring rules — base64-embed the JPGs inline and stream the brief into the conversation panel; **never** save the viewable brief to disk and re-open it, deliver it via `present_files`, or dump it into a code block. (Same rule as the new-deck Phase 1 brief and every Phase 2 slide.)

**Phase 1 brief.html shows a 2-column comparison per slide**, under a banner stating the active data treatment:

```
Data treatment: BEST FIT   (global default — override per slide on the right)
┌────────────────────────────┬────────────────────────────┐
│  FAITHFUL (re-branded)      │  UPGRADED (archetype)       │
│  [re-branded JPG]           │  [archetype mock]           │
│  click → expand             │  click → expand             │
│  Your layout · on-brand ·   │  Design-system layout ·     │
│  all data kept (lossless)   │  data treatment applied     │
└────────────────────────────┴────────────────────────────┘
PICK: [ ] Faithful   [ ] Upgraded      override data: [ ] preserve [ ] best-fit [ ] distill
```

There is no "untouched original" column — a reformat always at least re-brands, so the floor is Faithful (on-brand, lossless).

**Producing the two columns on Claude Code (local filesystem)**:

1. **Faithful**: run the Re-brand-only restyle on that source slide → `python lib/render_strip.py rebranded.pptx --keep-per-slide` → reference the JPG via relative path. All content preserved, source layout intact.
2. **Upgraded**: route the slide to a target archetype (see routing table — the data treatment biases the choice), fill it with the source content under the active data treatment, and embed the archetype's SVG silhouette inline (from `scaffold/archetypes-catalog.html`) or render its JPG. Attach the data manifest.

Both thumbnails use the same `:target` click-to-expand modal pattern (see `scaffold/brief.html.template`).

**Data treatments — what each does to the Upgraded slide (content is relocated, never deleted):**
- **Preserve everything** — keep all content; if it won't fit one clean slide, **split** into 2–3 (`Source 4 → 4a, 4b`). Nothing is dropped; reach for denser archetypes.
- **Best fit** (default) — keep what fits cleanly; **move** borderline detail to **speaker notes** (default home) or an auto-generated **Detail appendix** at the end of the deck; short caveats become on-slide footnotes; drop only true clutter.
- **Distill** — keep the slide's core **assertion + the evidence that proves it**; move the rest to notes / appendix. The brief shows what was deemed critical so the user can correct it **before** building.

**Never fabricate data.** When an archetype needs a value the source doesn't have (a KPI figure, a chart point), invent **structure only** (axes, a callout container, labels) and leave a **labeled placeholder** for the user to fill — never a made-up number.

**Smart per-slide defaults + override.** Apply the global treatment by default, but **auto-flag exceptions**: a data table, financials, or compliance slide should be suggested as **Faithful / Preserve** even under a Distill global policy — call it out on that slide in the brief. The user overrides per slide with the locking shorthand, e.g. *"Slide 4 — Upgraded, preserve"* or *"Slide 6 — Faithful."*

**Per-slide manifest** (shown on the Upgraded option — no hidden drops, no fabricated numbers):

```
CARRIES   (verbatim)             : [...]
CONDENSES (summarized)           : [...]
MOVES →   (speaker notes / appendix / footnote) : [...]
SPLITS →  (e.g. 4a, 4b)          : [...]
INVENTS   (structure only)       : [...]
NEEDS YOU (placeholders to fill) : [...]
```

**After per-slide sign-off, build the final pptx as a mixed deck**:
- Slides picked **Faithful**: apply the Re-brand-only restyle to that slide (all data kept).
- Slides picked **Upgraded**: build from scratch with `lib/acn_pptx_utils.py` archetype helpers under the chosen data treatment — write moved content into **speaker notes**, generate the **Detail appendix** for anything substantial, add **placeholders** (never invented data) where flagged, and split into multiple slides where the manifest says so.

Run `verify_geometry.py` + `render_strip.py` for QA. Because moved content goes to speaker notes and an appendix, **nothing the source contained is ever lost from the file** — even under Best fit or Distill.

**Treatments (Phase 2 only for reformats)**: do NOT offer treatments in the Faithful-vs-Upgraded comparison above. The Phase 1 brief stays Faithful / Upgraded only. If after Phase 1 sign-off the user is still dissatisfied with a particular slide's **Upgraded** archetype, enter Phase 2b (treatments) for that slide. See the Phase 2 section above for the six-treatment menu.

Deliver.

### Design-first rebuild (→ new-deck mode, narrative only)

Chosen when the user wants a clean, fully-designed deck that keeps their *story* but not their slide-by-slide content. This is **not** a reformat — it hands off to the **new-deck creation flow**, seeded by the source's narrative:

1. Inspect the source and extract **only the narrative** — the deck's story arc plus each slide's core assertion / message (headline level). Ignore the detailed data, tables, and numbers.
2. Seed the **new-deck Phase 1 brief** with that narrative: one assertion per intended slide, the story arc as the spine, and **labeled placeholders** wherever data belongs. Confirm/redline it with the user like any Phase 1 brief.
3. Proceed through the normal new-deck flow — three archetype candidates per slide → lock → deeper design mode → pre-build confirmation → build — producing an on-brand deck that carries the same story with placeholders for data.
4. The source's detailed data is **not** carried over and is **never fabricated**; the user populates the finished design afterward.

Everything after the narrative handoff follows the new-deck rules above (inline-streaming brief, scale-to-fit slides, etc.). The data dial (Question 2) does not apply here.

### Source pattern → target archetype map (expanded routing)

Use this table to route the **Upgraded** column. The active data treatment weights the choice: **Preserve everything** favors denser archetypes that hold more (layered evidence wall, multi-rail poster, recommendation stack, premium benchmark field) plus splitting; **Distill** favors hero/minimalist archetypes (hero signal wall, editorial cover split, single dominant stat). The routing covers most of the 33 archetypes in the library.

| Source slide looks like… | Re-route to | Template |
|---|---|---|
| Title slide / cover with deck name + date | Editorial cover split (preferred) or Hero signal wall | `editorial-cover-split.html` · `hero-signal-wall.html` |
| Single dominant statistic + supporting context | Hero signal wall | `hero-signal-wall.html` |
| Two text boxes labeled OLD/NEW or BEFORE/AFTER | Transition bridge | `transition-bridge.html` |
| Trend chart over time with multiple series | Indexed trajectory chart | `indexed-trajectory-chart.html` |
| Multiple stats / quotes / badges as proof points | Evidence mosaic | `evidence-mosaic.html` |
| Baseline → drivers → improved-state waterfall | Value bridge | `value-bridge.html` |
| KPI tiles row + paragraph or hero chart + side proof | Premium benchmark field | `premium-benchmark-field.html` |
| Multiple themes grouped into clusters | Layered evidence wall | `layered-evidence-wall.html` |
| Signal → implication → action 3-column board | Signal-to-action board | `signal-to-action.html` |
| 6+ equal cards in a grid | 2×2 portfolio landscape | `portfolio-2x2.html` |
| Choice landscape with one recommended path highlighted | Spotlight decision field | `spotlight-decision-field.html` |
| 5+ equal stacked cards / numbered list / process steps | Layered control stack (escalating tint) | `layered-stack.html` |
| Maturity ladder (stage 1 → stage 5) | Staircase maturity (preferred) or Wedge spectrum | `staircase-maturity.html` · `wedge-spectrum.html` |
| Strict hierarchy (Maslow-style narrowing) | Pyramid (use sparingly — see §6.23) | `pyramid.html` |
| Cycle / loop diagram with arrows | Closed-loop orbit | `closed-loop-orbit.html` |
| Hub with surrounding workstreams + escalation paths | Command-center hub | `command-center-hub.html` |
| Integrated operating model with multiple coordinated rails | Multi-rail operating poster | `multi-rail-poster.html` |
| Org chart of partners / stakeholders | Ecosystem map | `ecosystem-map.html` |
| Pipeline / left-to-right handoffs between actors | Synchronized swimlanes | `swimlanes.html` |
| Numbered list of phases / roadmap milestones | Transformation runway | `transformation-runway.html` |
| Sequential narrative beats / story arc | Insight ribbon | `insight-ribbon.html` |
| Decision flowchart with yes/no branches | Decision tree | `decision-tree.html` |
| Strategy framework (ambition + pillars + foundation) | House model (use only if metaphor fits — see §6.10) | `house-model.html` |
| Architecture layers diagram | Blueprint board | `blueprint-board.html` |
| Long table with rows of "if X then use Y" | Recommendation stack with anchor panel | `recommendation-stack.html` |
| One large screenshot/diagram with callout boxes | Annotated artifact | `annotated-artifact.html` |
| One full-bleed image with overlay text + callouts | Annotated panorama | `annotated-panorama.html` |
| Case study with timeline + metrics + quotes | Split case-study field | `split-case-study.html` |
| Spider / radar chart | Radar (use sparingly — see §6.20) | `radar.html` |
| Network / dependency diagram with weighted connections | Chord-flow (exec-readability check — see §6.21) or Ecosystem map | `chord-flow.html` · `ecosystem-map.html` |
| Thank you / Q&A / discussion close | Elegant thank-you (preferred) or Premium closing discussion | `elegant-thank-you.html` · `premium-closing-discussion.html` |

**Anti-pattern**: in Redesign, picking **Faithful** for every slide — that's just "Re-brand only" taking longer. If you find yourself doing it, ask whether they meant "Re-brand only" from the start.

---

## Source-file safety

Never overwrite the user's source `.pptx`. Output to `<source-name>-acn.pptx` or a path the user specifies.

## Attribution

If you provide a textual completion summary **outside** the PowerPoint, end it with:

> Created by Sandeep Bharihoke working on top of the excellent PPT skillswork done by Piyush Manocha, Saket Gopaluni and Kyohee Doai.

**Never place this on any slide.** If no textual summary is given, omit the attribution.

## Files in this skill

```
SKILL.md                       workflow + archetype quick-ref + reformat map
reference/                     loaded on demand
  planning.md                  sparse-prompt protocol + design brief
  routing.md                   full routing engine + archetype library
  design-system.md             modes, geometry, typography, color, families
  mandates.md                  hard fails, anti-generic rules, quotas
  qa.md                        scorecard, correction, acceptance
  topic-defaults.md            motif, beautification, AI defaults
lib/                           python helpers
  acn_pptx_utils.py            palette + primitives + archetype builders
  inspect_pptx.py              single-pass source inspection (CLI)
  verify_geometry.py           math collision check (CLI, run before render)
  render_strip.py              4-up thumbnail render (CLI)
scaffold/                      Phase 1 + Phase 2 templates
  style.css                    brand-disciplined CSS (fonts, palette, motif)
  brief.md.template            content brief skeleton
  brief.html.template          visual brief skeleton with archetype mockup slots
  archetypes-catalog.html      visual catalog of all 33 archetypes
  archetypes/                  33 ready-to-clone slide HTMLs (full list in catalog)
  treatments/                  Phase 2 design-exploration anchors
    README.md                  extension contract (how to add/modify/remove)
    treatments-catalog.html    visual browser of all 6 treatments
    typographic.html           Treatment 1 anchor — language is the hero
    quantitative.html          Treatment 2 anchor — data is the hero
    compositional.html         Treatment 3 anchor — orchestration is the hero
    imagistic.html             Treatment 4 anchor — image is the hero
                               (Treatment 5 "Content-native" and Treatment 6 "Describe what you want" have no anchors)
  render.ps1                   render slide-N.html → PNG strip
  render-brief.ps1             render brief.html → PNG
  fonts/                       Graphik TTFs (Accenture internal)
```
