# Render brief.html to brief.png (tall full-page screenshot).
# Usage:
#   .\render-brief.ps1                                # uses current directory
#   .\render-brief.ps1 -Workspace C:\path\to\deck
param(
  [string]$Workspace = (Get-Location).Path,
  [string]$Chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe",
  [int]$Height = 4400
)

if (-not (Test-Path $Chrome)) {
  $edge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
  if (Test-Path $edge) { $Chrome = $edge }
  else { Write-Error "Chrome not found"; exit 1 }
}

$html = "$Workspace\brief.html"
$png  = "$Workspace\brief.png"
if (-not (Test-Path $html)) { Write-Error "brief.html not found in $Workspace"; exit 1 }
if (Test-Path $png) { Remove-Item $png }
$url = "file:///" + ($html -replace "\\", "/")
$udd = Join-Path $env:TEMP "cd_$([guid]::NewGuid().ToString('N').Substring(0,8))"
$proc = Start-Process -FilePath $Chrome -ArgumentList @(
  "--headless=new", "--disable-gpu", "--hide-scrollbars",
  "--no-sandbox", "--disable-extensions", "--allow-file-access-from-files",
  "--user-data-dir=$udd",
  "--window-size=1300,$Height",
  "--screenshot=$png",
  "$url"
) -PassThru -WindowStyle Hidden
$proc.WaitForExit(30000) | Out-Null
if (-not $proc.HasExited) { $proc.Kill() }
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $udd
if (Test-Path $png) {
  Write-Output "wrote brief.png ($([Math]::Round((Get-Item $png).Length/1024,1)) KB)"
} else {
  Write-Output "FAILED to render brief.png"
}
