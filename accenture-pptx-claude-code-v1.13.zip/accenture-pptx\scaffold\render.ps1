# Render all slide-N.html files to slide-N.png, then assemble a 4-up strip.
# Usage:
#   .\render.ps1                              # uses current directory as workspace
#   .\render.ps1 -Workspace C:\path\to\deck   # explicit workspace path
#
# Requires Chrome + Python with PIL (`pip install pillow`).
param(
  [string]$Workspace = (Get-Location).Path,
  [string]$Chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"
)

if (-not (Test-Path $Chrome)) {
  # try Edge as a fallback
  $edge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
  if (Test-Path $edge) { $Chrome = $edge }
  else { Write-Error "Chrome not found at $Chrome and no Edge fallback"; exit 1 }
}

Get-ChildItem "$Workspace\slide-*.html" | Sort-Object Name | ForEach-Object {
  $html = $_.FullName
  $png = $html -replace "\.html$", ".png"
  if (Test-Path $png) { Remove-Item $png }
  $url = "file:///" + ($html -replace "\\", "/")
  $udd = Join-Path $env:TEMP "cd_$([guid]::NewGuid().ToString('N').Substring(0,8))"
  $proc = Start-Process -FilePath $Chrome -ArgumentList @(
    "--headless=new", "--disable-gpu", "--hide-scrollbars",
    "--no-sandbox", "--disable-extensions", "--allow-file-access-from-files",
    "--user-data-dir=$udd",
    "--window-size=1280,720",
    "--screenshot=$png",
    "--default-background-color=00000000",
    "$url"
  ) -PassThru -WindowStyle Hidden
  $proc.WaitForExit(15000) | Out-Null
  if (-not $proc.HasExited) { $proc.Kill() }
  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $udd
  if (Test-Path $png) { Write-Output "rendered $($_.Name)" } else { Write-Output "FAILED $($_.Name)" }
}

# Combine into a 2x2 (or 3xN) strip via PIL
$pyScript = @"
from PIL import Image
import glob, os
ws = r'$Workspace'
files = sorted(glob.glob(os.path.join(ws, 'slide-*.png')))
if not files:
    print('no PNGs to combine'); exit()
ims = [Image.open(f) for f in files]
target_w = 640
scale = target_w / ims[0].width
target_h = int(ims[0].height * scale)
ims = [im.resize((target_w, target_h), Image.LANCZOS) for im in ims]
n = len(ims)
cols = 2 if n <= 4 else (3 if n <= 9 else 4)
rows = (n + cols - 1) // cols
gutter = 12
strip = Image.new('RGB',
                  (cols * target_w + (cols + 1) * gutter,
                   rows * target_h + (rows + 1) * gutter),
                  (245, 245, 242))
for i, im in enumerate(ims):
    r, c = divmod(i, cols)
    x = gutter + c * (target_w + gutter)
    y = gutter + r * (target_h + gutter)
    strip.paste(im, (x, y))
out = os.path.join(ws, '_strip.png')
strip.save(out, 'PNG', optimize=True)
print(f'wrote {out}  ({n} slides, {cols}x{rows} grid)')
"@
$pyTmp = "$Workspace\_strip.py"
$pyScript | Set-Content -Encoding utf8 $pyTmp
python $pyTmp
Remove-Item $pyTmp
