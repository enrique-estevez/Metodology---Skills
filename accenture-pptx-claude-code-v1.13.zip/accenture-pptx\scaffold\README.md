# Scaffold — Phase 1 and Phase 2 templates

This folder holds the HTML/CSS/markdown templates that Phase 1 (content brief +
HTML mockups) and Phase 2 (optional slide-by-slide HTML iteration) use.

## What's here

| File | Purpose | Phase |
|---|---|---|
| `style.css` | Brand-disciplined CSS: Graphik @font-face, palette tokens, header/footer system, motif rail. **Do not edit per deck** — keep brand-consistent across decks. | 1 + 2 |
| `fonts/Graphik-*.ttf` | Graphik font weights referenced by `style.css`. Accenture internal use only. | 1 + 2 |
| `brief.md.template` | Content brief skeleton — copy to `<workspace>/brief.md` and fill in. | 1 |
| `brief.html.template` | Visual brief skeleton with archetype mockup slots — copy to `<workspace>/brief.html`. | 1 |
| `archetypes/recommendation-stack.html` | Ready-to-clone slide: 5 rows + chips + anchor panel. | 2 |
| `archetypes/layered-stack.html` | Ready-to-clone slide: 5 tiers with progressive tint. | 2 |
| `archetypes/swimlanes.html` | Ready-to-clone slide: A–E rows with handoff chips. | 2 |
| `archetypes/portfolio-2x2.html` | Ready-to-clone slide: 2×2 with square dots + legend. | 2 |
| `render.ps1` | Render `slide-*.html` → PNG + assemble 4-up strip. Run from workspace. | 2 |
| `render-brief.ps1` | Render `brief.html` → tall PNG. Run from workspace. | 1 |

## How to use (per deck)

```powershell
# 1) Create a workspace folder for the deck
mkdir C:\Users\<you>\Downloads\<deck-name>-html
cd C:\Users\<you>\Downloads\<deck-name>-html

# 2) Copy scaffold contents into it
$scaffold = "$env:USERPROFILE\.claude\skills\accenture-pptx\scaffold"
Copy-Item "$scaffold\style.css" .
Copy-Item "$scaffold\fonts" . -Recurse
Copy-Item "$scaffold\brief.md.template" .\brief.md
Copy-Item "$scaffold\brief.html.template" .\brief.html
Copy-Item "$scaffold\render.ps1" .
Copy-Item "$scaffold\render-brief.ps1" .

# 3) Phase 1 — edit brief.md, render brief.html
.\render-brief.ps1

# 4) Phase 2 (optional) — copy archetype HTMLs as slide-1.html, slide-2.html, ...
Copy-Item "$scaffold\archetypes\recommendation-stack.html" .\slide-1.html
Copy-Item "$scaffold\archetypes\layered-stack.html" .\slide-2.html
# ...edit content of each, then:
.\render.ps1

# 5) Phase 3 — Claude writes the pptx generator using lib/acn_pptx_utils.py
```

## Editing rules

- **Never edit `style.css` per deck** — it carries brand discipline. Tweak per-slide CSS in `<style>` blocks inside each slide HTML.
- **Always link `style.css` first**, then add your slide-specific styles inside the HTML.
- **Keep the `.slide` container at `1280×720`** — that's the PowerPoint 16:9 widescreen design grid.
- **Use only `--purple-primary`, `--purple-deep`, `--purple-plum`, and the lavender tints** for purple. No new purple shades.
- **Squares not circles** — see how the portfolio-2x2 plot dots are squares. This is a hard brand rule.
