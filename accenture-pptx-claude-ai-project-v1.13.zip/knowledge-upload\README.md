# Project Knowledge — bulk upload guide

All 55 files in this folder are project knowledge for the Accenture deck-generator Claude.ai Project. They're laid out flat (no subfolders) so you can bulk-select and drag in one go.

## How to upload (Claude Desktop / web)

1. Open this folder in your file manager
2. Select all (Ctrl+A on Windows / Cmd+A on Mac)
3. Drag into the Claude.ai Project's **Knowledge** box
4. Wait for upload to complete
5. Done — Claude can now search and reference any of these files by name

## What's in here (55 files)

### Reference markdown (6)
The skill's design system, routing engine, mandates, and QA rubric.
- `planning.md` — Phase 1 sparse-prompt protocol + design brief fields
- `routing.md` — message-type → archetype routing engine + full archetype library
- `design-system.md` — modes, geometry, typography, color, slide families
- `mandates.md` — type-specific hard fails, anti-generic rules, diversity quotas
- `qa.md` — per-slide scorecard + correction protocol + acceptance checklist
- `topic-defaults.md` — motif menu, beautification techniques, AI/agentic defaults

### Python helpers (4)
Reference code Claude can read when writing the Phase 3 build script.
- `acn_pptx_utils.py` — palette + primitives + archetype builders (transition_bridge, layered_stack, swimlane_row, portfolio_2x2)
- `inspect_pptx.py` — single-pass source-pptx inspection (CLI)
- `verify_geometry.py` — math-only collision check (CLI)
- `render_strip.py` — cross-platform 4-up render (soffice+pdftoppm on Linux/Mac, PowerPoint COM on Windows)

### Phase 1/2 scaffold (5)
HTML/CSS templates for the content brief + slide mockups.
- `style.css` — brand-disciplined CSS (Graphik @font-face, palette tokens, motif rail, scale-to-fit frame)
- `brief.md.template` — markdown content brief skeleton
- `brief.html.template` — visual brief with archetype mockup slots + click-to-expand modal
- `slide.html.template` — Phase 2 slide skeleton with the scale-to-fit frame (`.slide-frame` / `.slide-scale`) baked in
- `archetypes-catalog.html` — visual catalog of all 33 archetypes grouped by family

### Archetype HTMLs (33)
Ready-to-clone slide templates, one per archetype. Claude picks one (or proposes a novel layout) per slide.

Stack family (6): `recommendation-stack.html`, `layered-stack.html`, `layered-evidence-wall.html`, `wedge-spectrum.html`, `staircase-maturity.html`, `pyramid.html`

Flow family (6): `swimlanes.html`, `transformation-runway.html`, `decision-tree.html`, `insight-ribbon.html`, `signal-to-action.html`, `value-bridge.html`

Matrix family (4): `portfolio-2x2.html`, `premium-benchmark-field.html`, `radar.html`, `chord-flow.html`

System family (4): `closed-loop-orbit.html`, `command-center-hub.html`, `multi-rail-poster.html`, `ecosystem-map.html`

Page-treatment family (9): `editorial-cover-split.html`, `hero-signal-wall.html`, `premium-closing-discussion.html`, `elegant-thank-you.html`, `split-case-study.html`, `annotated-artifact.html`, `annotated-panorama.html`, `spotlight-decision-field.html`, `blueprint-board.html`

Special (4): `transition-bridge.html`, `indexed-trajectory-chart.html`, `evidence-mosaic.html`, `house-model.html`

### Treatments — Phase 2 design exploration (7 files)
Offered as a Phase 2 fallback when canonical archetypes feel like boilerplate. Each treatment makes one thing the dominant attention vector on the slide.
- `typographic.html` — language is the hero (FT/NYT feature pages)
- `quantitative.html` — data is the hero (Tufte-style info-graphic)
- `compositional.html` — orchestration is the hero (Bloomberg explainer / Pentagram report)
- `imagistic.html` — image is the hero (full-bleed visual + overlays)
- `treatments-catalog.html` — visual browser of all 6 treatment options
- `treatments-README.md` — extension contract (how to add/modify/remove treatments)

## What's NOT here (intentionally)

- `render.ps1`, `render-brief.ps1` — local-execution scripts; not relevant as project knowledge
- `SKILL.md` — that's the Claude Code variant; the Claude.ai equivalent is in `../project-instructions.md`
- Graphik fonts — Claude.ai can't load TTFs; the in-artifact CSS uses a fallback chain (`Graphik → Inter → Helvetica Neue → system-ui`). Real Graphik rendering happens locally on the user's machine when they open the final .pptx.

## Note on relative paths inside files

Some HTML files reference `style.css` or `../style.css` for browser rendering. Inside Claude.ai's knowledge store, paths don't matter — Claude reads each file by name. The relative paths are only meaningful when the user opens the HTML locally in a browser.
