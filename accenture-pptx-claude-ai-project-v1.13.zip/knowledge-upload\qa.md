# QA, correction, and acceptance

Read **before** rendering to images. Run the geometry checker first (`lib/verify_geometry.py`) — it catches most issues mathematically without burning preview tokens.

## QA checklist (one structured pass — run before declaring done)

Work through this checklist once, in order. All four zones must clear — a deck can pass the build check and still fail as a document.

**① Build**
- Code runs without exceptions; no undefined refs; all images exist on disk before `add_image`
- Fresh argument objects per call (reusing mutates and corrupts later shapes)
- File opens and renders without error — a deck that won't open is an automatic fail
- **Headline reflow budget** — headline box height must be `font_pt × 2.4 / 72` inches (~0.76" at 22pt, ~1.0" at 30pt). Strapline must start at or after `headline_y + that height`. `GEOMETRY PASS` is not sufficient for headline/strapline pairs; the static checker cannot model text reflow.

**② Visual & aesthetic** (render to images, inspect in this order)
- **Mandatory headline-band check** — explicitly confirm the headline does not collide with the strapline. This is the most common silent defect; the geometry checker cannot catch it.
- **Lazy-box audit first** — more than one slide with a lazy row of equal boxes/cards? → rebuild as real structured exhibits; **no wavy-line roadmaps** (`mandates.md` §17.6); **no exhibit split into multiple image fragments** (one exhibit = one image)
- Richness quota: ≥3 exhibits transcend a plain deck; ≥1 is a true hero
- **Flat-2D** — no 3D extrusion, bevel, isometric, perspective, or drop-shadow slab anywhere (`mandates.md` §17.5)
- **Heroes clear the bar** — smooth curves / custom geometry / illustration with a focal point; not a flat shape that should have been native
- **All text native** — every label, value, axis tick, callout is a native text box; nothing rasterized into an image (`design-system.md` §19.3)
- **One system** — one palette, one grid, one type scale, one icon family across every slide
- **Composition** — each exhibit fills its zone; nothing overflows safe margins; no overlap or off-grid drift
- **Aesthetic craft** — clear focal point; consistent grid alignment; even whitespace; balanced weight; body contrast ≥4.5:1; type floor ~11pt; no accent line directly under titles

**③ Story & structure**
- Every core slide **asserts** (conclusion headline) and answers "so what" (implication stated)
- Specific, not generic; every figure sourced or labelled `Illustrative` honestly
- Human partner voice; no LLM tells; headlines grammatical and complete
- No two slides make the same point; nothing reusable-for-any-client
- **Title-only test** — read just the headlines top to bottom; do they alone tell the argument and reach the decision? If not, fix the headlines — not the body
- **Ship gate** — would a partner put their name on this and send it to the client? If not, name the weakest 2–3 slides, rebuild, and re-review

**④ Consulting rigor**
- **Strategic context** — a clear *why now* (driving force + cost of inaction), not just a solution
- **Options shown** — real alternatives (incl. do-nothing) visible, with *why this one* on the client's criteria; a recommendation with no road-not-taken reads as a pitch
- **Balanced caveats** — key risks and weakest points named honestly, not buried; sharpest objection steel-manned
- **Conditions for value** — every projected value claim states what must be true to realize it; an unconditioned number is a pitch
- **Advisor test** — would a sceptical CFO who distrusts vendors find this *fair*? If it only flatters the recommendation, send it back

---

## 18. Per-slide QA scorecard

### 18.1 Score 1–5

| | Category | Question |
|---|---|---|
| A | **Narrative strength** | Does the headline make a point? Implication clear? Does the slide advance the story? |
| B | **Graphic existence & silhouette** | Real primary graphic object? Silhouette reads in thumbnail? Visual does explanatory work? |
| C | **Asset fit** | Right medium for the message? Should this have been a chart, image-led board, or system view? Are icons/charts/images helping rather than decorating? |
| D | **Visual distinctiveness** | Avoids looking like a standard card grid? Silhouette distinct from neighbors? |
| E | **Premium finish** | Composed, not merely aligned? Enough focal tension, contrast, polish? Partner-ready not analyst-safe? |
| F | **Density control** | Appropriately rich without clutter? Scannable in layers? |
| G | **Brand & discipline** | Feels like a real Accenture-style page? Spacing, fonts, colors, rules disciplined? |

### 18.2 Passing rules
- Minimum total = **29 / 35**
- No category below 4 on executive core slides
- If **B**, **C**, or **E** score below 4 → slide **auto-fails**

### 18.3 Hard-fail checks (any one fails the slide)
- No clear primary graphic object
- Mostly equal cards or text rectangles
- Meaning depends almost entirely on paragraphs
- Silhouette too similar to preceding slide
- Could be mistaken for a rough wireframe
- Looks like default PowerPoint plus good alignment
- Generic enough to apply to any topic with only copy changes
- Obviously should have used a chart, image-led board, or system view but did not

### 18.4 Type-specific hard fails
See `mandates.md` §14.

### 18.5 Blur / thumbnail / rectangle-ratio test
View as thumbnail. Strong dominant silhouette? Primary graphic still reads? Over-dependent on rectangles? Blocky wireframe → not finished.

### 18.6 Wall test
Place all slides side by side mentally. One polished deck? At least three different visual families? One hero slide? Enough rhythm? Opener and close intentionally related?

---

## 19. Correction and rebuild protocol

### 19.1 Correction happens before output, not after criticism

### 19.2 Four levels

| Level | When | Fix |
|---|---|---|
| **1 — Surface polish** | Core route right, finish weak | spacing · scale hierarchy · material contrast · accent placement · callout integration · density balance · icon sizing · chart labeling |
| **2 — Art direction** | Structurally correct, not premium enough | strengthen focal surface · reduce rectangle dependence · replace boxes with arcs/bands/wedges/rails · improve chart composition · improve image crop · functional iconography · improve opener/close |
| **3 — Structural** | Right story, wrong page architecture | change primary graphic object · recompose · rebalance modules · replace equal-card layouts with integrated system · switch text-led proof to chart-led · switch abstract boxes to image-led |
| **4 — Full rebuild** | Fundamentally generic, box-led, underdesigned | no clear silhouette · fails graphic existence · fails asset fit · wireframe-like · too similar to neighbors · still weak after one structural pass |

### 19.3 Rebuild preference
Choose the least box-dependent candidate route from the original option set unless it reduces clarity.

### 19.4 Cover, slide 2, and final page deserve extra scrutiny
Opener defines perceived quality. First proof page determines strategic-vs-superficial feel. Closing page determines resolved-vs-unfinished feel.

---

## 20. Deck-level wall review before final output

### 20.1 Storyline
Coherent executive narrative? Commercially logical order? Final substantive slide creates action/decision momentum?

### 20.2 Visual rhythm
Distinct page grammars? Balance of hero, proof, system, motion? Any slide clearly weaker? Rectangle dependence still too visible deck-wide?

### 20.3 Brand continuity
One deck? Consistent typography, accent logic, subtle motif? Icon/chart/image treatments feel like one visual language?

### 20.4 Premium enough for the audience
Would this feel credible in front of a CEO or board? Does at least one page feel memorable? Are visuals doing enough work? Does the opener feel polished enough? If closing page, does it feel like a designed bookend?

---

## 21. Acceptance checklist

**Narrative** — headline makes a point · slide supports it with proof or structure · next slide follows logically.

**Geometry** — objects on repeated anchor points · consistent margins · aligned columns · consistent footer · some key pages use more than rectangle grids.

**Design** — looks like an Accenture deck not a generic AI template · purple restrained and purposeful · dense content modular and framed · images/boards/charts docked to grid · clear focal point · distinct silhouette · icons consistent and functional.

**Content** — language specific and business-realistic · numbers/stages/stakeholders/implications concrete or clearly labeled `illustrative` · no placeholder filler · no two slides making the same point.

**Consulting rigor (advises, not pitches)** — strategic context + real options shown (incl. do-nothing) + honest balanced caveats · every value claim states its conditions to materialize · recommendation still sharp after the rigor, not hedged away · advisor test passed.

**Title-only test** — reading just the headlines top to bottom tells the full argument and reaches the decision. If not, fix the headlines.

**Premium finish** — feels designed not assembled · enough contrast in scale and emphasis · ≥1 strong visual object · intentional in thumbnail · charts/images/complex graphics earn their place · opener and close (if included) feel premium.

**Structural exhibits native** — architecture / roadmap / process / matrix / swimlane built as native shapes + connectors (never baked) · no roadmap drawn as wavy line + ovals · no exhibit fragmented into multiple image files.

**Hero discipline** — each hero exhibit is one SVG → one PNG → one `add_image()` call · SVG carries marks only (no text glyphs baked in) · every label placed as native text at its anchor · flat 2D only (no 3D / extrusion / bevel anywhere).

**Ship gate** — would a partner put their name on this and send it to the client? If not, identify the weakest slides, rebuild, and re-review.

**Polish** — no overlaps · no cropped text · no awkward dead space · no rogue fonts · no decorative noise · no weak filler slide · no under-designed cover or closing page.
