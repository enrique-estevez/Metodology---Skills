# Treatments — extension contract

This folder holds **treatments**: design approaches offered as a Phase 2 fallback when the canonical 33 archetypes feel like boilerplate. Each treatment makes **one thing** the dominant attention vector on the slide.

## What's here

| File | Treatment | Hero (dominant attention vector) | One-line characterization |
|---|---|---|---|
| `typographic.html`    | Typographic   | Language      | Large display type, magazine rhythm (FT / NYT / MIT Tech Review feature pages) |
| `quantitative.html`   | Quantitative  | Data          | Tufte-style info-graphic; small multiples + sparklines + dense annotation |
| `compositional.html`  | Compositional | Orchestration | Multi-panel editorial board (Bloomberg explainer / Pentagram annual report) |
| `imagistic.html`      | Imagistic     | Image         | Full-bleed visual field with overlay structure; the image carries the page |
| `treatments-catalog.html` | — | — | Visual browser of all six treatment options |

The remaining two treatment options have no anchor file:
- **Content-native** — reasons from content's structural type (flow / hierarchy / comparison / system / magnitude) to design a bespoke native exhibit from first principles
- **Describe what you want** — blank-canvas mode where the user describes the design and Claude generates from scratch within brand discipline

## How treatments are used (Phase 2 only)

Treatments are **never** offered in Phase 1. Phase 1 sticks to the canonical 33 archetypes (with the existing "novel candidate" pattern). Treatments enter only when:

1. Phase 1 archetypes are picked and the brief is locked
2. The user signals dissatisfaction in Phase 2 ("show me something different" / "explore designs" / "none of these feel fresh")
3. Claude opens the treatments catalog and the user picks one

Claude reads the picked anchor HTML as **inspiration**, not as a template to clone. The output is a fresh HTML artifact in that treatment's spirit, with the user's locked Phase 1 content filled in.

## Non-negotiable brand discipline (applies to every treatment)

The treatment changes the *composition logic*, not the brand layer. These rules hold for every generation:

- **Palette**: only the 11 Accenture tokens (`PURPLE_PRIMARY`, `PURPLE_DEEP`, `PURPLE_PLUM`, `LAVENDER`, `LAVENDER_2`, `WHITE`, `NEUTRAL_LIGHT`, `NEUTRAL_MID`, `DIVIDER`, `LABEL_GRAY`, `BLACK`)
- **Typography**: Graphik (with web fallback to Inter / Helvetica Neue / system-ui in artifacts; embedded as Graphik in the .pptx)
- **Squares not circles**: angular elements for accent shapes, dots, badges, callouts. Ovals only for genuine "people" icons.
- **Light-mode default**: dark surfaces only on hero panels, section dividers, or full-bleed imagistic slides
- **16:9 widescreen**: `13.333 × 7.5` inches, with the canonical band system from `design-system.md`
- **Primary graphic object**: every treatment slide still needs one — no decorative-only pages
- **§18 QA scorecard**: Claude must self-pass before showing the user (graphic existence ≥4, asset fit ≥4, premium finish ≥4)

## Extension contract — adding / modifying / removing treatments

### To add a new treatment

1. Create a new anchor HTML in this folder (e.g., `editorial-print.html`). The anchor must:
   - Link to `../style.css`
   - Use the brand-disciplined CSS variables (no hard-coded hex outside the 11 tokens)
   - Demonstrate the treatment's composition logic with placeholder content (`[Headline]`, `[Strapline]`, etc.)
   - Pass the §18 QA scorecard at thumbnail size
2. Add a row to `treatments-catalog.html` (copy an existing card, swap the SVG silhouette + name + characterization)
3. Add a line to `SKILL.md`'s "Treatments" section (and mirror to `project-instructions.md` for Claude.ai)
4. For Claude.ai: copy the new HTML into `claude-ai-project/knowledge-upload/` flat folder

That's it — no Python or code changes.

### To modify a treatment

Edit the anchor HTML and the one-line characterization in `SKILL.md` / `project-instructions.md` / this README's table.

### To remove a treatment

Delete the anchor HTML, remove the catalog card, remove the line from SKILL.md / project-instructions.md, and remove the flat copy from `knowledge-upload/`.

## Why these four anchored treatments specifically

The four anchored treatments were chosen as **mutually exclusive attention vectors** — each makes one thing the hero of the page. They span the major modes of contemporary editorial / data-viz / brand-design practice:

- Language-led (Typographic)
- Data-led (Quantitative)
- Orchestration-led (Compositional)
- Image-led (Imagistic)

The remaining two options (Content-native, Describe what you want) reason from scratch with no anchor — they extend the menu beyond fixed archetypes into first-principles and open-canvas territory.

If you find yourself wanting to add a fifth named treatment, ask: is it actually a *new attention vector*, or is it a variation of one of the four? If variation, extend the existing treatment's anchor. If new vector, add a new treatment.

## On "Describe what you want" (the sixth, anchor-less option)

This is the open-canvas mode. The user describes the design they want — by reference ("like a Bloomberg explainer feature"), by feel ("data-dense but with editorial whitespace"), or by pointing at an external example. Claude generates fresh HTML obeying the brand-discipline guardrails above, with no anchor to draw from.

Higher variance than the named treatments. Claude must run a stricter self-QA pass before showing the result, because there's no anchor to compare against. If the generation can't pass QA, Claude says so and offers to fall back to one of the five named treatments.
