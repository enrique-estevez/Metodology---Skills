# Slide-type hard fails, anti-generic rules, diversity quotas

Read while planning each slide and before final QA.

## 14. Hard-fail checks by slide type

### 14.1 Shift slides
Must use a visible change mechanism. **Allowed**: transition bridge, split-screen model shift, staged evolution spectrum, old-vs-new operating system with value implications. **Hard fail** if just two text boxes with OLD/NEW labels or the shift is only described verbally.

### 14.2 Value-at-stake / prize slides
Must have a real analytic backbone. **Allowed**: chart, benchmark spread, value bridge, value pool, indexed gap over time. **Hard fail** if mainly KPI tiles or no spatial/analytic structure.

### 14.3 Where-to-play / deployment slides
Must have true portfolio or spectrum logic. **Allowed**: portfolio map, staged wedge, maturity/control landscape, value-risk matrix. **Hard fail** if three equal cards.

### 14.4 System / loop / architecture logic
Must feel engineered. **Allowed**: loop, layered control stack, blueprint, hub and rails, flow map with feedback. **Hard fail** if just four labeled boxes with arrows.

### 14.5 Roadmap / path-forward
Must feel like motion and compounding capability. **Allowed**: transformation runway, phased maturity path, journey with gates, lanes with milestones. **Hard fail** if basically a formatted table of phases and bullets.

### 14.6 Recommendation slides
Must surface what leadership should do. **Preferred**: recommendation stack · choice architecture with highlighted path · decision tree with recommended route · prioritized move set with sequence logic.

### 14.7 Cover / opener slides
**Hard fail** if mostly empty space plus title and one decorative color block · could apply to any topic by changing only the title · no strong visual surface or organizing geometry.

### 14.8 Closing / thank-you / discussion
**Hard fail** if only centered `Thank you` on a blank page · disconnected from rest of deck · feels like an afterthought.

### 14.9 Quantitative evidence slides
**Hard fail** if numeric but mostly prose or equal tiles · a chart was clearly possible but not attempted.

### 14.10 Image-led / complex-board slides
**Hard fail** if abstract even though a system view, screenshot-like board, panorama, or image-emulating field would explain faster.

### 14.11 Icon usage
**Hard fail** if oversized, decorative, inconsistent, or used as wallpaper.

---

## 15. Visual diversity quotas for short executive decks

### 15.1 For 3–5 slide executive deck, deliver at minimum:
- 1 premium opener or hero framing page
- 1 chart-led or benchmark-led proof page
- 1 portfolio, landscape, or choice architecture page
- 1 systems, control-loop, architecture, or operating-model page
- 1 journey, runway, or transformation page

### 15.2 Geometry and asset quotas
- ≥2 slides with a dominant geometry that is **not** a simple rectangle grid
- ≥1 slide with a chart or true analytic graphic when quantitative logic exists
- ≥1 slide using icons or visual anchors to improve scanning
- ≥1 slide tests whether imagery/screenshot/image-emulating field strengthens the story

### 15.3 Repetition limits
- No more than one slide may be primarily card-led
- No more than one slide may use equal-width repeated boxes as dominant structure
- No two adjacent slides share the same core silhouette
- No three rectangular-block-dominated pages in a row
- No more than two substantive slides feel mostly box-built (unless intentionally document-like)

### 15.4 Visual sequence rhythm (5-slide exec)
1. Premium framing
2. Proof tension
3. Strategic choice
4. Engineered logic
5. Motion / action
6. (Optional) Elegant discussion or thank-you page

### 15.5 If a slide role cannot be satisfied strongly
Merge into a stronger page rather than keeping a weak filler slide.

---

## 16. Anti-generic rules

### 16.1 Box-dominance threshold
If >65% of body is occupied by simple axis-aligned rectangles primarily containing text → presume weak (unless intentionally table-like).

### 16.2 Equal-card warning
3+ equal cards in a row/grid → challenge: could this be a portfolio, spectrum, map, or integrated system instead?

### 16.3 Shape-only ≠ designed
Using native shapes does not automatically qualify as designed. Must show hierarchy of scale, visual direction, distinct silhouette, narrative logic.

### 16.4 Rectangles allowed but must do different jobs
Vary scale, vary role, vary material, embed into a stronger organizing system.

### 16.5 Avoid false complexity
Do not add lines/icons/mini-labels to look advanced. Only add detail that improves meaning.

### 16.6 Avoid over-minimalism
Consulting deck should not look under-built. Empty ≠ premium.

### 16.7 Avoid pseudo-premium gimmicks
No random gradients, big glows, oversized icons, vague abstract shapes, decorative shadow abuse, consumer-app aesthetics.

### 16.8 No icon wallpaper
If icons are not improving orientation/labeling/module structure, remove them.

### 16.9 No generic cover logic
No big title + one generic gradient block as default cover.

### 16.10 No generic closing logic
Do not end with unstyled `Thank you` on white.

### 16.11 No chart-paste behavior
If a chart looks Excel-exported and dropped in untouched → fail.

### 16.12 Do not replace every visual need with rectangles
When the page calls for a curve, orbit, wedge, matrix, layered board, image field, or spotlight, use it.

### 16.13 Complexity is allowed if it is legible
Do not oversimplify. Complex consulting visuals are acceptable when hierarchy is clear, page remains scannable, visual logic earns its complexity.

---

## 17. Native-build doctrine and hero discipline

### 17.1 Lazy-default check (mandatory before building any slide)

**If your first instinct is a row of equal cards/boxes/text panels — STOP.** That is the cue you defaulted. Return to the message and design the real structure. Ask: what job does this content need done? Route through `design-system.md` §16 (job-organized palette). Equal cards are permitted at most once per deck, and only for genuinely parallel items with no deeper structure.

*(A rectangle that names a real component, layer, phase, swimlane, or cell is NOT a lazy card — those are workhorses and are correct and good.)*

### 17.2 Native-first doctrine for structural exhibits

The following slide types **must always be built as native shapes + native connectors** in python-pptx — never baked as an image:

- Architecture and system diagrams (tonal horizontal bands + labeled component tiles + native connector lines with arrowheads)
- Roadmaps and timelines (time axis + workstream lanes + duration bars + milestone diamonds)
- Process flows and pipelines (uniform station shapes on a straight rail + native directional arrows)
- Swimlanes (role bands + step chips + native connectors between them)
- Matrices and 2×2 charts
- Layered stacks and capability models

**Hard fail:** if any of these appears as a `<p:pic>` image element in the pptx XML, it must be rebuilt native.

### 17.3 One exhibit = one image (no fragmentation)

A hero exhibit is exactly **one** SVG → **one** PNG → **one** `add_image()` call. If you are placing several PNGs for a single visual idea, stop — that is the "compressed / low-fidelity" failure. Build it native instead, or as one composed image.

Inspect the output: if a single exhibit has more than one `<p:pic>` element, it is fragmented — rebuild.

### 17.4 All text must be native

Every headline, label, value, axis tick, callout, and data annotation must be a native `<a:t>` text run in the pptx — never a text glyph baked into an image. This includes labels that appear over a hero SVG: the SVG carries marks only, and every label is placed afterward as a native text box at the calculated anchor (see `design-system.md` §19.3).

**Hard fail:** if any label, number, or title appears inside an image element rather than as a native text run, rebuild it native.

### 17.5 Flat 2D — absolute ban list

**Banned on every slide, every exhibit, every shape:**

- 3D extrusion, 3D rotation, beveled edges
- Isometric blocks or perspective "roads"
- Drop-shadow "slabs" (a shadow that creates the illusion of depth)
- Skeuomorphic gloss, heavy glow, blur
- Any shape where the fill looks like it has a light source or a vanishing point

**Test:** if a shape looks lit or has depth, flatten it. Replace extruded architecture layers with flat tonal bands. Replace isometric diagrams with flat schematic layouts.

### 17.6 Wavy-line roadmap ban

A roadmap or process flow drawn as a **wavy / decorative line with beads or ovals as phases** is a hard fail. A roadmap is a native time/lane/milestone exhibit. The structure *is* the schedule — a left-to-right time axis, workstream lanes with duration bars, milestone diamonds at real points, thin connectors for dependencies.

### 17.7 No flat-panel baked images

A flat rectangular panel or box baked as an image (for example, a gradient background rectangle exported as PNG) is banned — it is neither editable nor premium. Build it as a native shape with a flat fill or, if a gradient is needed, as a narrow accent band only (see `design-system.md` §17).
