# Planning ritual, message map & content standards

Read this **once at the start of every deck build**, before writing any code.

---

## 1. Message map — plan the argument before any slide

Write and sharpen this before designing a single visual:

- **Governing question** — the one question the audience is really asking (e.g. *"Should we fund an agentic claims program now, and how?"*).
- **Audience + the decision** they must make (approve / fund / choose / prioritize / greenlight).
- **Strategic context** — why this matters *now*: the market / competitive / regulatory / economic force driving the decision, and the **cost of inaction**. Frame the decision before answering it (see §1A below).
- **One-sentence answer** — your recommendation, in a single sentence.
- **Options considered & why this one** — the real alternatives weighed (including do-nothing) and the basis for the call. A recommendation with no visible road-not-taken reads as a pitch (§1A).
- **Argument beats (3–5)** — the chain that gets from the question to the answer. Each beat is one slide's job. They must *connect*: beat 2 should depend on beat 1, not restate it.
- **Skeptic's question** — the sharpest objection a smart executive will raise, and which slide answers it.
- **Balanced caveats** — where the recommendation is weakest, key risks, conditions under which you'd change it. Stated plainly, not buried (§1A).
- **Conditions for value** — what must be true for the projected value to materialize: the preconditions, dependencies, and client actions required, plus the risks to realization (§1A).
- **Evidence** — the proof behind each beat (your data, cited research, or labelled illustrative).
- **Slide plan** — per slide: `role · assertion · so-what · native-or-hero`.

A deck needs a **spine**: a governing question and an argued chain. **Every slide delivers insight, not summary.** If a slide only describes, cut it or convert it to an insight.

### 1A. Advise, don't pitch — the consultant stance

A partner is a **trusted advisor**, not a vendor. A pitch asserts upside and differentiation; an advisor does that *and* frames the context, shows the options, owns the trade-offs, and is honest about what has to be true. Build all four into every deck:

- **Strategic context first.** Before the answer, establish *why now* — the market, competitive, regulatory or economic force driving the decision, and the cost of doing nothing.
- **Show the options, not just the answer.** Name the real alternatives considered (including do-nothing) and *why* this one wins on the client's criteria. The road not taken is what makes the chosen road credible — build/buy/partner, now/next/later, narrow/broad: the genuine fork, never a strawman.
- **Balanced caveats — intellectual honesty.** State where the recommendation is weakest, the key risks, and the conditions under which you'd change it. Steel-man the objection; don't dodge it.
- **Conditions for value — what must be true.** Every value claim carries the preconditions, dependencies, and **client actions** required for it to materialize. *"≈18% lower cost-to-serve"* is a pitch; *"≈18% — if clean-claim volume holds, the COB rules migrate by Q2, and adjusters are re-skilled"* is advice.

**Guardrail — balanced is NOT wishy-washy.** The recommendation stays *sharp and singular*; rigor sharpens credibility, it never softens the call. A deck that hedges every claim fails as badly as one that over-promises. **Advisor test:** would a sceptical CFO who distrusts vendors find this *fair*? If it only flatters the recommendation, fix it.

---

## 2. Content standards (apply to every slide)

### 2.1 Specificity is the credibility engine

Name the **tool / method / segment / place / date / unit**. Numbers are real and sourced, or labelled `illustrative` with the basis stated.

| Generic (weak) | Specific (partner-grade) |
|---|---|
| "AI makes claims faster." | "Auto-adjudication takes clean claims from days to under an hour; only exceptions reach a human." |
| "Significant cost savings." | "≈18% lower cost-to-serve, driven mainly by deflected manual touches in adjudication and COB." |
| "Improve the customer experience." | "First-pass accuracy rises and rework loops disappear, so providers stop chasing status." |

**Test:** if a sentence is equally true for any other client or any other vendor, it isn't content yet — sharpen it until it could only be said here.

### 2.2 Evidence & sourcing

Every figure resolves to one of four, and the deck is **honest about which**:
1. **Your data / the client's data** — use as given; attribute its source.
2. **Labelled placeholder** — tag `Illustrative` and state the basis. Use a plausible figure, never a raw token like `XX%` *unless* the user asked for a fillable shell.
3. **Cited secondary research** — external, public, attributed. Name the source and year.
4. **Never** synthesized-as-fact, an invented source, or a fabricated precise number.

**Gate by genre:** PoV / thought-leadership → secondary + illustrative is fine. Client engagement → ask which. Reformat → carry the source's own data unchanged. Fillable shell → leave clean `[ ]` tokens and don't invent.

### 2.3 Density calibrated to audience

| Audience | Density |
|---|---|
| Board / C-suite | spare, assertion-led; every line specific |
| Exec working session | medium, discussable — issue trees, option matrices |
| Steering committee | status + asks — RAID, milestone tracks |
| RFP / evaluator | dense, proof-backed — blueprints, traceability |
| CTO / architect | technical, layered — target-state arch, data flow |

Three lines that each carry a mechanism and a number beat six vague ones.

### 2.4 Human partner voice — kill the LLM tells

Write like a senior partner briefing an executive: varied sentence rhythm, earned authority, recommendation-led. **Pair conviction with candor** — an advisor states the recommendation plainly *and* names the real risk beside it.

Banned tells (these scream "AI wrote this"):
- Rule-of-three triads on every line ("faster, smarter, better").
- The "X, not Y" snap as a reflex ("it's a platform, not a pilot") — fine once, deadly when repeated.
- "where it counts", "at its core", "in today's landscape", "ever-evolving".
- An em-dash punch in *every* headline.
- A literal "**So what:**" label stamped on every slide — *make* the implication, vary its wording and placement.
- Hedging filler: *leverage, holistic, best-in-class, synergy, north star, unlock potential, seamless, robust* — banned unless genuinely precise.

**Read-aloud test:** read each headline and lead line aloud. If it sounds like a LinkedIn post, rewrite it until it sounds like a person who knows the topic.

### 2.5 Assertion headlines & the implication

- **Each headline states a conclusion**, not a topic. Not *"Operating model"* but *"Buy the platform; build only the bank-specific layer."* Headlines read top to bottom ARE the executive summary (title-only test in QA).
- **Every core slide answers four questions:** what this means · why it matters · what changes · what decision it tees up. The last is the **implication** — one sharp line that turns the slide into a reason to act. No implication ⇒ cut the slide or sharpen it.

### 2.6 Content hard-fails (any one = rewrite)

Descriptive (non-asserting) headline · no implication · a claim equally true for any client · two slides making the same point · a recommendation the deck didn't earn · fake or unsourced precision · buzzwords standing in for mechanisms · LLM-cadence prose · ungrammatical or incomplete headline · a pure pitch with no strategic context or genuine options · a value claim with no conditions for it to materialize · caveats so heavy the recommendation turns wishy-washy.

---

## 0. Prompt austerity — the skill carries the burden

Short prompts like *"Build a 5-slide executive deck on agentic AI impact on business"* must yield rich outcomes. Do not over-prompt the user.

### 0.1 Infer automatically from sparse prompts
audience seniority · deck mode · slide count within the requested range · story arc · degree of proof required · appropriate visual diversity · whether a cover is needed · whether a path-forward or recommendation slide is needed · whether a system or architecture page is needed · appropriate information density and polish level

### 0.2 Default assumptions for sparse executive prompts
- audience = C-suite / board / senior business leadership
- mode = Mode A unless implementation detail is clearly the point
- duration = 4–5 slides if user says 3–5
- tone = serious, premium, commercial, concise, recommendation-led
- detail level = enough to support decision making, not appendix density
- structure = opener + proof + choice + operating logic + path forward
- design ambition = client-ready consulting quality, not safe wireframe
- default ratio of synthesis to detail = 70 / 30

### 0.3 Do not ask the user for obvious missing details
Do not interrupt with questions like *"How many slides exactly?"* (range provided), *"What visual style?"* (defined here), *"Do you want graphics?"* (required), *"Do you want a roadmap?"* (implied by topic). Only ask follow-ups when a missing fact would materially alter content and no reasonable assumption exists.

### 0.4 A minimal prompt must still yield
coherent storyline · assertion-led headlines · multiple slide roles · meaningful visual variety · premium page composition · a strong final QA pass.

---

## 3. Internal planning ritual

### 3.1 Design brief (emit BEFORE any code as a 5-line decision table)

```
audience  : <C-suite | senior leadership | partners | working team>
mode      : <A: executive story | B: proposal/delivery | hybrid>
count     : <N substantive slides; cover/close = inline | dedicated | omitted>
arc       : <topic family A/B/C/D, see §3.6>
motif     : <one of: control rails, progressive wedges, orbital rings, …>
```

### 3.2 Slide-role plan for short executive decks

**Default core sequence**:
1. Premium opener / shift / framing / stakes
2. Proof / economics / benchmark / why now
3. Choices / portfolio / where to play / decision architecture
4. System / operating model / capability logic / governance loop
5. Path forward / roadmap / actions / transformation motion

**Optional bookends**: Cover (separate premium title page when standalone) · Closing (Thank you, Discussion, Next steps when it improves polish).

### 3.3 Slide-count interpretation
If a tight count is given without flexibility, assume it refers to **substantive pages**. Slide 1 may double as cover and first insight page.

### 3.4 Compression rules
- **3 slides** → combine opener + proof; combine system + path forward
- **4 slides** → keep opener, proof, choice, path forward; embed system into proof or roadmap
- **5 slides** → full sequence

### 3.5 If more than five
Add: case study, sector implications, operating model detail, org/governance view, architecture, use-case prioritization, risk and controls, implementation workstreams, premium close.

### 3.6 Topic-based default story arcs

| Family | Arc |
|---|---|
| **A. Frontier tech / AI / automation / digital op model** | what is changing → why economically → where to pursue first → how the system works → how to scale safely |
| **B. Market / growth / strategy** | market shift → prize or risk → strategic choices → winning model → strategic moves |
| **C. Transformation / op model / enterprise modernization** | current constraint → value pool → target-state model → enabling capabilities and controls → phased transformation path |
| **D. Delivery / implementation / proposal** | objective and scope → proposed approach → workstreams and roles → roadmap and governance → team / credentials / assumptions |

### 3.7 Asset plan is mandatory
Identify: which slide carries the strongest chart, strongest non-rectilinear visual, where imagery/screenshot strengthens credibility, where icons act as functional anchors, where the most premium page sits.

---

## 4. Minimal-prompt execution protocol

### 4.1 With only topic and slide count
Still do all of: choose deck mode, choose default storyline, decide whether slide 1 is integrated opener, decide whether separate cover is warranted, decide whether closing page is warranted, decide visual sequence, select hero moment, select strongest chart/proof slide, choose governance/operating placement, run QA before output.

### 4.2 When the user says "exec presentation"
Short deck · strong headlines · sharp visuals · no appendix tone · fewer words but stronger structure · bigger message hierarchy · more premium composition · at least one page with clear board-level takeaway · zero tolerance for filler pages.

### 4.3 When the user says nothing about design
Assume client-ready output · real graphics · stronger page architecture · charts where quantitative logic exists · icons sparingly but meaningfully · image-led or complex-board treatments where they add credibility.

### 4.4 Cover/closing rule under sparse prompts
- Tight slide budget → slide 1 functions as premium opener + first story page
- Standalone presentation with flexible count → dedicated cover acceptable
- Closing Thank you / Discussion / Next steps only when it strengthens polish without replacing a needed core insight slide
- Never insert empty bookend pages that feel formulaic

### 4.5 If evidence is limited
Cite widely known directional evidence; label numbers as `illustrative` if synthesized; avoid fake precision; never invent named sources; if no robust quantitative evidence exists, use an evidence wall, scenario field, or structured implication board instead of a fake chart.
