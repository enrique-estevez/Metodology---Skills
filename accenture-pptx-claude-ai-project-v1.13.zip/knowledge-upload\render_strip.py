"""
Render a .pptx to a 4-up thumbnail strip PNG. Cross-platform.

  - Linux / macOS:  uses `soffice --headless` + `pdftoppm` (preferred for servers)
  - Windows:        uses PowerPoint COM via PowerShell

The model only needs to read ONE strip image during QA — not N separate slide JPGs.

Usage:
    python render_strip.py path/to/deck.pptx [--out strip.png] [--keep-per-slide]

Requires Python with PIL (`pip install pillow`).
Linux/Mac additionally need `libreoffice` (soffice) and `poppler-utils` (pdftoppm).
"""
import sys
import os
import argparse
import tempfile
import shutil
import subprocess
import platform
from pathlib import Path


def render_linux_mac(src_pptx, workdir):
    """Render via soffice → PDF → pdftoppm → JPGs. Returns list of JPG paths."""
    src_abs = os.path.abspath(src_pptx)
    # soffice produces <basename>.pdf in --outdir
    subprocess.run(
        ["soffice", "--headless", "--convert-to", "pdf",
         "--outdir", workdir, src_abs],
        check=True, capture_output=True, timeout=120,
    )
    pdf_path = os.path.join(
        workdir, Path(src_pptx).stem + ".pdf"
    )
    if not os.path.exists(pdf_path):
        raise RuntimeError(f"soffice did not produce {pdf_path}")

    # pdftoppm -jpeg -r 150 produces <prefix>-1.jpg, <prefix>-2.jpg, ...
    prefix = os.path.join(workdir, "slide")
    subprocess.run(
        ["pdftoppm", "-jpeg", "-r", "150", pdf_path, prefix],
        check=True, capture_output=True, timeout=120,
    )
    files = sorted(
        f for f in os.listdir(workdir)
        if f.startswith("slide-") and f.endswith(".jpg")
    )
    return [os.path.join(workdir, f) for f in files]


def render_windows(src_pptx, workdir):
    """Render via PowerPoint COM driven from PowerShell. Returns list of JPG paths."""
    src_abs = os.path.abspath(src_pptx).replace("\\", "\\\\")
    workdir_esc = workdir.replace("\\", "\\\\")
    ps = f"""
$ppt = New-Object -ComObject PowerPoint.Application
$ppt.DisplayAlerts = 1
$pres = $ppt.Presentations.Open('{src_abs}', $true, $true, $false)
$pres.SaveAs('{workdir_esc}', 17)
$pres.Close()
$ppt.Quit()
"""
    subprocess.run(
        ["powershell", "-NoProfile", "-Command", ps],
        check=True, capture_output=True, timeout=120,
    )
    files = sorted(
        f for f in os.listdir(workdir)
        if f.lower().startswith("slide") and f.lower().endswith(".jpg")
    )
    return [os.path.join(workdir, f) for f in files]


def assemble_strip(jpgs, out_png, cols=None):
    """Combine N slide JPGs into one strip PNG via PIL."""
    try:
        from PIL import Image
    except ImportError:
        print("ERROR: pillow required. pip install pillow", file=sys.stderr)
        return False

    images = [Image.open(f) for f in jpgs]
    if not images:
        print("ERROR: no slides to combine", file=sys.stderr)
        return False

    n = len(images)
    if cols is None:
        cols = 2 if n <= 4 else (3 if n <= 9 else 4)
    rows = (n + cols - 1) // cols

    target_w = 640
    scale = target_w / images[0].width
    target_h = int(images[0].height * scale)
    images = [im.resize((target_w, target_h), Image.LANCZOS) for im in images]

    gutter = 12
    strip = Image.new(
        "RGB",
        (cols * target_w + (cols + 1) * gutter,
         rows * target_h + (rows + 1) * gutter),
        (245, 245, 242),
    )
    for i, im in enumerate(images):
        r, c = divmod(i, cols)
        x = gutter + c * (target_w + gutter)
        y = gutter + r * (target_h + gutter)
        strip.paste(im, (x, y))

    strip.save(out_png, "PNG", optimize=True)
    print(f"wrote {out_png}  ({n} slides, {cols}x{rows} grid, "
          f"{strip.width}x{strip.height}px)")
    return True


def check_tools(system):
    """Verify required tools exist. Return None if ok, otherwise error message."""
    if system in ("Linux", "Darwin"):
        for tool in ("soffice", "pdftoppm"):
            if shutil.which(tool) is None:
                return (
                    f"ERROR: `{tool}` not found on PATH. "
                    f"Install with:\n"
                    f"  apt-get install -y libreoffice poppler-utils   # Debian/Ubuntu\n"
                    f"  brew install libreoffice poppler                # macOS"
                )
    elif system == "Windows":
        # PowerPoint COM check is harder; assume installed on a Windows workstation
        pass
    else:
        return f"ERROR: unsupported platform: {system}"
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", help="path to .pptx")
    ap.add_argument("--out", default=None,
                    help="output PNG (default: <deck>_strip.png alongside source)")
    ap.add_argument("--cols", type=int, default=None,
                    help="thumbnails per row (default: auto)")
    ap.add_argument("--keep-per-slide", action="store_true",
                    help="also copy per-slide JPGs into a sibling _preview/ folder")
    args = ap.parse_args()

    src = os.path.abspath(args.path)
    if not os.path.exists(src):
        print(f"ERROR: not found: {src}", file=sys.stderr); sys.exit(1)

    system = platform.system()
    err = check_tools(system)
    if err:
        print(err, file=sys.stderr); sys.exit(1)

    base = os.path.splitext(os.path.basename(src))[0]
    out_png = args.out or os.path.join(os.path.dirname(src), f"{base}_strip.png")
    workdir = tempfile.mkdtemp(prefix="acn_strip_")

    try:
        if system in ("Linux", "Darwin"):
            jpgs = render_linux_mac(src, workdir)
        elif system == "Windows":
            jpgs = render_windows(src, workdir)
        else:
            print(f"ERROR: unsupported {system}", file=sys.stderr); sys.exit(1)

        if not jpgs:
            print("ERROR: no slides rendered", file=sys.stderr); sys.exit(1)

        if args.keep_per_slide:
            preview_dir = os.path.join(os.path.dirname(src), f"{base}_preview")
            os.makedirs(preview_dir, exist_ok=True)
            for f in jpgs:
                shutil.copy(f, preview_dir)
            print(f"per-slide JPGs in {preview_dir}")

        if not assemble_strip(jpgs, out_png, cols=args.cols):
            sys.exit(1)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


if __name__ == "__main__":
    main()
