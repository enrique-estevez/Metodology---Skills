"""
Single-pass inspector for an existing .pptx.

Usage:
    python inspect_pptx.py path/to/deck.pptx [--max-text 120]

Prints slide dimensions, layout names, every shape with its position, fill
state, and (truncated) text. Also pulls table contents inline. Designed so
one invocation gives the model everything it needs to plan a reformat.
"""
import sys
import argparse

if sys.stdout.encoding != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from pptx import Presentation


def shape_summary(sh, max_text=120):
    try:
        x = sh.left / 914400 if sh.left is not None else 0
        y = sh.top / 914400 if sh.top is not None else 0
        w = sh.width / 914400 if sh.width is not None else 0
        h = sh.height / 914400 if sh.height is not None else 0
    except Exception:
        x = y = w = h = 0

    txt = ""
    if sh.has_text_frame:
        txt = sh.text_frame.text.replace("\n", " | ")
        if len(txt) > max_text:
            txt = txt[:max_text] + "…"

    fill = ""
    try:
        if sh.fill.type == 1:  # solid
            rgb = sh.fill.fore_color.rgb
            fill = f" fill=#{rgb}"
    except Exception:
        pass

    return f"  [{sh.shape_type}] @({x:.2f},{y:.2f}) {w:.2f}×{h:.2f}{fill}  {txt!r}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--max-text", type=int, default=120)
    args = ap.parse_args()

    p = Presentation(args.path)
    print(f"file: {args.path}")
    print(f"size: {p.slide_width/914400:.3f} × {p.slide_height/914400:.3f} in")
    print(f"slides: {len(p.slides)}")
    print("=" * 80)

    for i, slide in enumerate(p.slides, 1):
        print(f"\n— SLIDE {i} — layout: {slide.slide_layout.name}")
        for sh in slide.shapes:
            print(shape_summary(sh, args.max_text))
            if sh.has_table:
                print("    TABLE:")
                for ri, row in enumerate(sh.table.rows):
                    cells = [c.text.replace("\n", " / ") for c in row.cells]
                    print(f"      r{ri}: {cells}")


if __name__ == "__main__":
    main()
