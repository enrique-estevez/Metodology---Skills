# Design system — modes, geometry, typography, color

All constants are also encoded in `lib/acn_pptx_utils.py` — prefer importing from there over re-typing values.

## 9. Deck modes

### Mode A — Executive Strategy / Growth / Transformation
Board, leadership, investment, growth, GTM, partnership, value creation, market narrative, transformation case.

**Visual cues**: large assertion headline near top · optional supporting strapline · more breathing room than proposal decks but still content-rich · section labels in utility band · native graphic composition · hero gradients on covers, dividers, case studies, key-message slides.

**Content behavior**: synthesis first, detail second · numbers and proof, main message prominent · reader gets the point in a few seconds, then goes deeper.

### Mode B — Proposal / Technical / Operating Model / Delivery
RFP responses, delivery approach, mobilization, roadmaps, governance, PMO/TMO, architecture, enterprise platforms, workstream design, org model.

**Visual cues**: smaller/more formal title band · strapline on most slides · footer with copyright and page number visible · more document-like and denser · repeated workstream boards, tables, screenshots acceptable · higher density acceptable if framed and aligned.

### Hybrid rule
Cover, context, market case, recommendation, executive summary in Mode A; approach, workstreams, governance, roadmap, architecture, team, appendix in Mode B.

### Decision rule
- **persuade / recommend / summarize / position / synthesize** → Mode A
- **respond / detail / govern / architect / mobilize / deliver / implement** → Mode B
- **both** → Hybrid sequence

---

## 10. Template, layout, geometry

### 10.1 Slide size — **16:9 widescreen only** → `13.333 × 7.5 in`

### 10.2 Horizontal bands

| Band | y range |
|---|---|
| Utility band | top edge to `y ≈ 0.25` |
| Headline band | `y ≈ 0.18 – 0.55` |
| Strapline band | `y ≈ 0.76 – 1.20` |
| Content body | `y ≈ 1.30 – 6.90` |
| Footer band | `y ≈ 7.10 – 7.35` |

### 10.3 Safe margins
- primary left margin = `x = 0.42`
- primary right safe edge = `x = 12.92`

### 10.4 Canonical x-anchors
- **Full width**: `x = 0.42`, `w = 12.50`
- **Two-column split**: left `x = 0.42` · right `x = 6.21` or `6.70–6.80` · gutter `0.25–0.35`
- **Three-up row**: `x = 0.27, 4.60, 8.93` · width per block `4.19`
- **Five-up gallery**: `x = 0.39, 2.94, 5.48, 8.03, 10.58` · width per card `2.38`
- **Six-up capability row**: `x = 0.42, 2.51, 4.61, 6.71, 8.80, 10.90` · width per block `~2.02`

### 10.5 Canonical y-anchors
**Mode A**: utility label `y = 0.00–0.05` · headline `y = 0.42` · strapline `y = 1.10` · module header row `y = 1.26` · big content start `y = 1.75 or 2.07`.
**Mode B**: headline `y = 0.18` · strapline `y = 0.76` · banner/workstream bar `y = 1.32–1.40` · dense content blocks `y = 1.75–2.35` · footer `y = 7.12`.

### 10.6 Discipline
Every slide should look like it came from the same invisible grid. Do not freehand placement. Asymmetry allowed; chaos not.

---

## 11. Typography

### 11.1 Primary font
**Graphik** (Semibold / Medium / Black for emphasis). Fallback: **Arial**. Do not default to Calibri or Aptos.

### 11.2 Mode A hierarchy (pt)
utility label 8–9 · headline 18–24 · large hero message 28–40 · strapline 10.5–12 · module headers 12–16 · body 10.5–12 · KPI figures 24–28 · footnote/footer 8–9.

### 11.3 Mode B hierarchy (pt)
title band 14–18 · strapline 10–12 · section/board headers 12–14 · body copy 9–11 · dense table 8–10.5 · profile names 20–24 · footer 8–9.

### 11.4 Weight
headline = Semibold/Black · strapline = Regular · module header = Semibold · body = Regular · KPI numbers = Black or Semibold.

### 11.5 Casing
- Mode A → sentence case preferred
- Mode B → uppercase acceptable for title bands, section labels, framework names
- maintain one casing logic consistently inside the same deck

### 11.6 Text behavior
Headlines read like conclusions, not labels. Straplines sharpen/qualify the headline. Body copy short, modular, scannable. No pasted paragraphs.

---

## 12. Color and material system

### 12.1 Core Accenture purples
- `#A100FF` — primary accent (`PURPLE_PRIMARY`)
- `#7500C0` — secondary deep purple (`PURPLE_DEEP`)
- `#460073` — dark plum / authority (`PURPLE_PLUM`)

### 12.2 Supporting lights and neutrals
- `#E6DCFF` / `#EBDEFF` — pale lavender (`LAVENDER`, `LAVENDER_2`)
- `#FFFFFF` — white canvas
- `#E6E6DC` / `#E6E6E6` — light neutral
- `#96968C` / `#969696` — medium neutral label tone
- `#BFBFBF` / `#D8D8D8` / `#F2F2F2` — dividers / borders / light surfaces
- `#000000` — primary text

### 12.3 Accent usage
Purple is a **signal**, not wallpaper. Dark purple for headers, emphasis bars, hero panels, critical focal elements. Pale lavender for grouped backgrounds. Most slides still read as mostly white or light-neutral.

### 12.4 Gradients
**Allowed**: covers · section dividers · key-message hero panels · image-side panels in case studies.
**Not allowed**: random card fills · decorative ribbons · gradient overload.

### 12.5 Lines and borders
Thin lines only. Light gray or purple rules to organize content. Avoid heavy black boxes.

### 12.6 Material hierarchy
- white = default information surface
- pale tint = grouped support module
- dark purple/gradient = hero emphasis only
- line-only containers = light structure
- no more than 2–3 surface materials on a standard page

---

## 13. Slide family library

| # | Family | Use for |
|---|---|---|
| 1 | Editorial opener / shift page | First slide or opening section |
| 2 | Proof-led chart page | Economics, why now, scale, benchmark gap |
| 3 | Portfolio / choice architecture | Where to play, prioritization, options |
| 4 | System loop / operating mechanism | How it works, op model, governance |
| 5 | Transformation runway | Roadmap, path forward, scale journey |
| 6 | Case study split | Case study, proof, credentials |
| 7 | Capability stack / foundation | Capabilities, enablers, foundations |
| 8 | Recommendation | What leadership should approve or sequence |
| 9 | Blueprint / architecture board | Target-state architecture, ecosystems |
| 10 | Dense appendix / assumptions | Detail, fidelity, reference |
| 11 | Premium cover / opener | Standalone deck opener or slide-1 hero |
| 12 | Premium close / thank-you | Formal close, discussion |
| 13 | Chart-led proof | Economics, divergence, benchmark evidence |
| 14 | Image-led / complex-board | System context, case study, blueprint |

---

## 14. Two-mode visual system — decide per slide before building anything

Every slide's primary exhibit must be resolved to one of two modes before any code is written:

### WORKHORSE — native editable shapes + connectors (the backbone)

Use when the content's structure is **discrete parts + connections** — components, layers, steps, lanes, phases, cells, a matrix, a comparison, a flow. Native shapes + native connectors in python-pptx are fully editable, perfectly crisp, and **premium in their own right** when lifted by the polish system (§17).

- Architecture and system views, layered stacks, swimlanes, process flows, roadmaps/timelines, matrices, comparison tables, stat-walls, org/governance structures → **always native, never baked as an image.**
- A rectangle that names a *real thing* — a system component, a layer, a phase, a swimlane, a matrix cell, a boundary — is correct and good. The failure is the *lazy* row of equal cards that merely holds list items.

### HERO — one custom flat-2D SVG → rasterize → one PNG (the minority)

Use when the content's truth is **curvilinear, illustrative, organic, geographic, or un-buildable from rectangles** — diverging trajectories, a value curve, a map, a quantified bridge, an annotated artifact, a complex flow-field.

- Compose one SVG with marks only (no `<text>` elements, no 3D).
- Rasterize to PNG at ≥2× (see §19 for the pipeline).
- Embed as **one single `add_image()` call** — never fragment one exhibit into multiple PNGs.
- Add every label as a native text box at the calculated anchor (§19.3).

**The routing test:** Is the content's structure discrete parts + connections? → **WORKHORSE.** Is its truth a continuous shape a rectangle can't make? → **HERO.** Default to native; reach for hero only when rectangles genuinely can't carry the idea.

**Richness quota:** a 6+ slide deck ships at least 3 exhibits that clearly transcend a plain deck — richly-crafted native workhorses and/or heroes — of which at least one is a true custom hero, plus one signature exhibit the deck is remembered for.

---

## 15. Premium-graphic reasoning process — reason to the form, don't pick from a menu

When a slide earns a hero (or even a complex workhorse), apply this process:

1. **Read the content's deepest structural truth.** Not "what topic is this" but "what *shape* is the idea" — how its parts actually relate. Spend real thought here.
2. **Imagine the best information designer handed this one point and a blank canvas.** What single custom visual makes it obvious at a glance? Describe it in words first — its organizing idea, composition, focal point, what the eye does first and next.
3. **Then build that** from the medium's primitives. The right answer is frequently a form no template would name.

**Worked example of the reasoning (not a template):** A slide argues *"value compounds for early movers and stalls for everyone else."* A template-picker reaches for two bullet columns. A designer sees the real shape — *two diverging trajectories over time* — and draws two curves separating on a shared timeline, the gap itself carrying the argument. Same content; one is a box slide, the other is a hero.

**What makes a hero premium (the bar to clear):**
- **Continuity over fragmentation** — one flowing, connected form reads richer than separated boxes.
- **Custom geometry** — the silhouette is specific to *this* content (a tapering attrition, an undulating journey, nested governance zones), not a generic rectangle with a label.
- **Tonal modeling, kept flat** — gradients and tints give depth-of-colour, never depth-of-space.
- **One focal point + intentional whitespace** — the eye knows where to start.
- **Marks only; narrative native** — the SVG is the picture; every word is native text anchored to its parts.
- **Restraint** — a few deliberate elements beat a busy one.

---

## 16. Job-organized visual palette (reason from the job, invent beyond the list)

Don't pick a form. Name the **job** the idea needs done, then reason to the visual that does it. This is a floor to reason FROM and BEYOND, not a menu to shop. Invent the form the content demands; the best exhibit is often one no list names.

**① Show structure — how the parts relate.** *Architecture, operating models, capabilities, ecosystems.*
- GOOD (native): tonal horizontal layers, labeled component tiles, real native connectors for data/control flow, a clearly drawn trust boundary. Editable; often the deck's signature.
- BAD: the diagram baked as one or several images; extruded 3D slabs; tiles no one can re-label or re-wire.

**② Show a flow — sequence, process, lifecycle.** *Journeys, pipelines, end-to-end processes.*
- GOOD (native): uniform stations on a straight rail, one icon per station, native arrows that encode direction, any branch drawn off the main line.
- BAD: ovals on a wobbly line; a chevron train; SmartArt cycle; arrows as decoration.

**③ Show a choice — options, positioning, where to play.** *Decisions, trade-offs, prioritization.*
- GOOD (native): axes that mean something, options plotted by evidence, the recommended one accented in the system hue; a scorecard rates options against the client's criteria.
- BAD: three equal cards labelled "Option A/B/C" with bullets; a 2×2 whose axes are decorative.

**④ Show magnitude — composition, contribution, drivers.** *Value, cost, mix, sensitivity.*
- GOOD (native): a waterfall/bridge whose bars sum the story; a value tree decomposing the headline number into levers.
- BAD: a number in a big box; a generic bar chart where a structured bridge was the point.

**⑤ Show change over time — roadmaps, adoption, maturity.** *Plans, sequencing, trajectories.*
- GOOD (native): a real schedule — left-to-right time axis, workstream lanes with duration bars, milestone diamonds at real points, thin connectors for dependencies, a "today" marker.
- BAD: a wavy decorative line with squished ovals as "phases"; a roadmap with no time axis, no duration, no dependencies.

**⑥ Show conditions for value — what must be true.** *Implementation-realism exhibit.*
- GOOD (native): each value step sits above the enabler(s) that unlock it and the risk that threatens it.
- BAD: a projected number with no visible conditions (that's a pitch).

**⑦ When baking earns its place — the hero (the minority).** *Only when the truth is curvilinear / illustrative / organic / geographic.*
- GOOD (one composed SVG): a value-at-stake area swelling along a curve; two diverging trajectories on a shared timeline; a map with tonal regions. One focal point, continuity over fragmentation, native labels over it.
- BAD: a flat panel with a baked gradient; a hub-and-spoke blob mirroring a list; any text baked in; an exhibit chopped into many image fragments.

---

## 17. Polish system — what lifts a native workhorse above a plain deck

Apply on every workhorse slide, in the deck's palette:

- **Tonal ordinal ramp** — encode hierarchy / sequence / intensity with **solid tints of the one system hue** (deep = high, mid = medium, grey = low). This alone makes tiers, stacks, and matrices read as designed.
- **Monoline icons** — single-stroke, consistent weight, usually inside a circle at a node or tier. One icon family; never mixed styles, never icons as wallpaper.
- **Gradient accent bands** — a gradient on a *header bar, divider, or sidebar* is the one place a small gradient image earns its place. Use sparingly; never a reason to rasterize a whole exhibit.
- **Purposeful connectors** — native arrows and lines that encode flow, sequence, dependency, or escalation. Directional and meaningful, never decorative.
- **Photography** — a relevant context photo (full-bleed or framed) and circular portrait crops for people. Real images where they belong; never stock clip-art.
- **A disciplined grid** — consistent margins, colored header bars, thin rules, dashed-border accent boxes used sparingly, generous whitespace, a persistent footer.
- All of it **flat 2D** — no 3D/extrusion/bevel/isometric/perspective anywhere.

---

## 18. Flat 2D — the look is crisp and flat

Premium consulting decks are **flat and 2D.** Richness comes from craft, colour, and custom form — never from fake depth.

- **Banned:** 3D extrusion, beveled/embossed edges, isometric blocks, perspective "roads," drop-shadow "slabs," skeuomorphic gloss, heavy glow/blur. These read as dated SmartArt and cheapen the deck instantly.
- **A common trap:** a layered architecture rendered as extruded 3D slabs. Use flat tonal bands instead — same structure, far more premium.
- **Allowed and good:** flat tonal gradients (as colour, not lighting), a single soft shadow used with great restraint for subtle separation, smooth 2D curves, clean custom polygons, crisp 1px rules.
- **Test:** if a shape looks like it has a light source or a vanishing point, flatten it.

---

## 19. Hero SVG pipeline (Phase 3 implementation)

Use this pipeline when a slide calls for a HERO exhibit (§14). All text must stay native — the SVG is marks only.

### 19.1 Author the SVG

```python
svg = """<svg xmlns="http://www.w3.org/2000/svg" width="1234" height="500">
  <!-- Author at the EXACT aspect ratio of the pptx rectangle this fills. -->
  <!-- marks only: paths, rects, circles, polygons, gradients — NO <text> -->
  <defs>
    <linearGradient id="g" x1="0" y1="1" x2="1" y2="0">
      <stop offset="0" stop-color="#460073"/>
      <stop offset="1" stop-color="#A100FF"/>
    </linearGradient>
  </defs>
  <path d="M120,400 C440,380 560,200 800,160 S1100,80 1180,60"
        fill="none" stroke="url(#g)" stroke-width="16" stroke-linecap="round"/>
  <path d="M120,440 C440,430 560,340 800,320 S1100,300 1180,300" fill="#E6DCFF"/>
  <circle cx="800" cy="160" r="16" fill="#A100FF"/>
</svg>"""
```

**Aspect-ratio rule:** author each hero SVG's `width:height` to the **exact aspect ratio of the pptx rectangle it will occupy**, not always 1280×720. A full-bleed body exhibit at `w:12.33, h:5.0 in` is ≈ 2.47:1, so author that SVG at ~`1234×500`, not `1280×720`. This prevents squished shapes.

### 19.2 Rasterize

```python
from lib.acn_pptx_utils import rasterize_svg
rasterize_svg(svg, "hero_slide3.png", width=2560)  # ≥2x for retina
```

`rasterize_svg()` tries: **cairosvg** (install: `pip install cairosvg`) → raises with install guidance if unavailable. If cairosvg is unavailable, fall back to headless Chrome: `chromium --headless --screenshot --window-size=2560,1040 hero.svg`.

### 19.3 Place the image + native labels

```python
from lib.acn_pptx_utils import add_image, hero_label_xy, add_text, PURPLE_PLUM, BLACK

# Place one image — never multiple fragments for one exhibit
img_x, img_y, img_w, img_h = 0.5, 1.5, 12.33, 5.0
add_image(slide, "hero_slide3.png", img_x, img_y, img_w, img_h)

# Every label is native text placed at its SVG anchor
lx, ly = hero_label_xy(img_x, img_y, img_w, img_h, cx_px=800, cy_px=160)
add_text(slide, lx - 0.9, ly - 0.15, 1.8, 0.30, "Early mover advantage", size=12, bold=True, color=PURPLE_PLUM)
```
