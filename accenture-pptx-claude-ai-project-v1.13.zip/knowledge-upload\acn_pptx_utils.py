"""
Accenture PPTX utilities — palette, primitives, archetype builders, hero pipeline.

Import this in your deck generator:

    from acn_pptx_utils import (
        # palette
        PURPLE_PRIMARY, PURPLE_DEEP, PURPLE_PLUM, LAVENDER, LAVENDER_2,
        WHITE, NEUTRAL_LIGHT, NEUTRAL_MID, DIVIDER, LABEL_GRAY, BLACK,
        # primitives
        add_rect, add_line, add_text, add_oval, add_chip, add_chevron,
        # furniture
        new_deck, header, footer,
        # core archetype builders
        transition_bridge, layered_stack, swimlane_row, portfolio_2x2,
        # extended archetype builders
        editorial_cover_split, hero_signal_wall, transformation_runway,
        blueprint_board, recommendation_stack, closed_loop_orbit, evidence_mosaic,
        # hero SVG pipeline (only for [HERO]-tagged slides)
        rasterize_svg, add_image, hero_label_xy,
    )

All x/y/w/h values are in inches (skill §10).
Slide size is forced to the canonical 13.333 × 7.5 (skill §10.2).

Two-mode visual system (reference/design-system.md §14):
  WORKHORSE — native shapes + connectors: architecture, roadmaps, process flows,
              swimlanes, matrices, stacks. Never bake these as images.
  HERO      — one custom flat-2D SVG (marks only, no <text>) → rasterize_svg()
              → one PNG → one add_image() call. Every label is a native add_text()
              placed at its anchor via hero_label_xy().
"""
import math
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor

# ────────────────────────────────────────────────────────────────────
# Palette — skill §12
# ────────────────────────────────────────────────────────────────────
PURPLE_PRIMARY = RGBColor.from_string("A100FF")
PURPLE_DEEP    = RGBColor.from_string("7500C0")
PURPLE_PLUM    = RGBColor.from_string("460073")
LAVENDER       = RGBColor.from_string("E6DCFF")
LAVENDER_2     = RGBColor.from_string("EBDEFF")
WHITE          = RGBColor.from_string("FFFFFF")
NEUTRAL_LIGHT  = RGBColor.from_string("F2F2F2")
NEUTRAL_MID    = RGBColor.from_string("E6E6E6")
DIVIDER        = RGBColor.from_string("D8D8D8")
LABEL_GRAY     = RGBColor.from_string("96968C")
BLACK          = RGBColor.from_string("000000")
DARK_GRAY      = RGBColor.from_string("3C3C3C")

# Progressive tier tints — for layered_stack escalation
TINT_RAMP = [
    NEUTRAL_LIGHT,
    LAVENDER_2,
    LAVENDER,
    RGBColor.from_string("D7BFFF"),
    RGBColor.from_string("C9A3FF"),
]
NUMERAL_RAMP = [LABEL_GRAY, PURPLE_DEEP, PURPLE_DEEP, PURPLE_DEEP, PURPLE_PLUM]

FONT = "Graphik"          # skill §11.1
FONT_FALLBACK = "Arial"

# Canonical anchors — skill §10.4, §10.6 Mode A
LEFT_MARGIN = 0.42
RIGHT_SAFE = 12.92
FULL_W = 12.50
HEADLINE_Y = 0.42
STRAPLINE_Y = 1.22     # after 2-line headline budget at 22pt (0.76") from y=0.42
RAIL_Y = 1.64          # under-strapline motif rail (strapline 1.22+0.38=1.60 + gap)
BODY_TOP = 1.78
FOOTER_Y = 7.18

SLIDE_W = 13.333
SLIDE_H = 7.5


# ────────────────────────────────────────────────────────────────────
# Primitives
# ────────────────────────────────────────────────────────────────────
def add_rect(slide, x, y, w, h, fill=None, line=None, line_w=None):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    s.shadow.inherit = False
    if fill is None:
        s.fill.background()
    else:
        s.fill.solid()
        s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        if line_w is not None:
            s.line.width = Pt(line_w)
    return s


def add_line(slide, x, y, w, h, color, weight=0.75):
    s = slide.shapes.add_connector(1,
                                   Inches(x), Inches(y),
                                   Inches(x + w), Inches(y + h))
    s.line.color.rgb = color
    s.line.width = Pt(weight)
    return s


def add_text(slide, x, y, w, h, text, size=11, bold=False, color=BLACK,
             align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, italic=False,
             font=FONT):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = text
    r.font.name = font
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    r.font.color.rgb = color
    return tb


def add_oval(slide, x, y, w, h, fill, line=None):
    s = slide.shapes.add_shape(MSO_SHAPE.OVAL,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    s.shadow.inherit = False
    s.fill.solid()
    s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = Pt(0.75)
    return s


def add_chip(slide, x, y, w, h, fill, text=None, text_color=WHITE,
             size=9, bold=True):
    s = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    s.shadow.inherit = False
    s.adjustments[0] = 0.35
    s.fill.solid()
    s.fill.fore_color.rgb = fill
    s.line.fill.background()
    if text is not None:
        tf = s.text_frame
        tf.margin_left = Emu(36000); tf.margin_right = Emu(36000)
        tf.margin_top = Emu(18000); tf.margin_bottom = Emu(18000)
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        r = p.add_run(); r.text = text
        r.font.name = FONT; r.font.size = Pt(size); r.font.bold = bold
        r.font.color.rgb = text_color
    return s


def add_chevron(slide, x, y, w, h, color):
    s = slide.shapes.add_shape(MSO_SHAPE.CHEVRON,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    s.shadow.inherit = False
    s.fill.solid(); s.fill.fore_color.rgb = color
    s.line.fill.background()
    return s


# ────────────────────────────────────────────────────────────────────
# Deck furniture
# ────────────────────────────────────────────────────────────────────
def new_deck():
    """Create a 16:9 widescreen presentation at the canonical size."""
    prs = Presentation()
    prs.slide_width = Inches(SLIDE_W)
    prs.slide_height = Inches(SLIDE_H)
    return prs


def add_blank(prs):
    """Add a blank slide using the blank master layout."""
    return prs.slides.add_slide(prs.slide_layouts[6])


def header(slide, title, strapline, utility=""):
    """Standard Mode A title block (skill §10.3, §11.2)."""
    if utility:
        add_text(slide, LEFT_MARGIN, 0.16, FULL_W, 0.22, utility,
                 size=8, color=LABEL_GRAY)
    add_text(slide, LEFT_MARGIN, HEADLINE_Y, FULL_W, 0.76, title,
             size=22, bold=True, color=PURPLE_PLUM)
    add_text(slide, LEFT_MARGIN, STRAPLINE_Y, FULL_W, 0.38, strapline,
             size=11, color=BLACK)
    # motif rail — short purple accent + long divider (skill §7.4)
    add_line(slide, LEFT_MARGIN, RAIL_Y, 1.40, 0, PURPLE_PRIMARY, weight=1.5)
    add_line(slide, LEFT_MARGIN + 1.43, RAIL_Y, FULL_W - 1.43, 0,
             DIVIDER, weight=0.5)


def footer(slide, page_num, total, label=""):
    if label:
        add_text(slide, LEFT_MARGIN, FOOTER_Y, 6.0, 0.22, label,
                 size=8, color=LABEL_GRAY)
    add_text(slide, RIGHT_SAFE - 1.0, FOOTER_Y, 1.0, 0.22,
             f"{page_num} / {total}",
             size=8, color=LABEL_GRAY, align=PP_ALIGN.RIGHT)


# ────────────────────────────────────────────────────────────────────
# Archetype builders — skill §6
# Each builder draws its archetype within a bounding box (x, y, w, h).
# Caller is responsible for placing it below the header band.
# ────────────────────────────────────────────────────────────────────
def transition_bridge(slide, x, y, w, h, *,
                      left_label, left_title, left_body,
                      right_label, right_title, right_body,
                      shift_label="SHIFT"):
    """Skill §6.1 — left=old, right=new, mechanism wedge in the middle.

    The right panel is the dominant one (deep plum, larger emphasis).
    """
    left_w = w * 0.33
    right_w = w * 0.55
    wedge_x = x + left_w + 0.10
    wedge_w = w - left_w - right_w - 0.20
    right_x = x + w - right_w

    # left panel — neutral, smaller emphasis
    add_rect(slide, x, y, left_w, h, fill=NEUTRAL_LIGHT)
    add_text(slide, x + 0.20, y + 0.18, left_w - 0.40, 0.28, left_label,
             size=9, bold=True, color=LABEL_GRAY)
    add_text(slide, x + 0.20, y + 0.50, left_w - 0.40, 0.80, left_title,
             size=15, bold=True, color=BLACK)
    add_text(slide, x + 0.20, y + 1.30, left_w - 0.40, h - 1.50, left_body,
             size=10.5, color=DARK_GRAY)

    # right panel — plum, dominant
    add_rect(slide, right_x, y, right_w, h, fill=PURPLE_PLUM)
    add_text(slide, right_x + 0.25, y + 0.18, right_w - 0.50, 0.28,
             right_label, size=9, bold=True, color=LAVENDER)
    add_text(slide, right_x + 0.25, y + 0.50, right_w - 0.50, 0.80,
             right_title, size=15, bold=True, color=WHITE)
    add_text(slide, right_x + 0.25, y + 1.30, right_w - 0.50, h - 1.50,
             right_body, size=10.5, color=LAVENDER_2)

    # mechanism chevron
    add_chevron(slide, wedge_x, y + h * 0.35, wedge_w, h * 0.30, PURPLE_PRIMARY)
    add_text(slide, wedge_x, y + h * 0.70, wedge_w, 0.30, shift_label,
             size=9, bold=True, color=PURPLE_PRIMARY, align=PP_ALIGN.CENTER)


def layered_stack(slide, x, y, w, h, tiers, *,
                  num_col_w=0.92, ex_col_w=3.55, gap=0.05):
    """Skill §6.7 — ascending tiers with progressive tint.

    tiers: list of dicts with keys: number, title, body, example (optional).
    Tier 1 = bottom of ramp, tier N = top. Tint and numeral color escalate.
    """
    n = len(tiers)
    tier_h = (h - (n - 1) * gap) / n
    main_x = x + num_col_w
    main_w = w - num_col_w - ex_col_w - 0.30

    for i, tier in enumerate(tiers):
        ty = y + i * (tier_h + gap)
        tint = TINT_RAMP[min(i, len(TINT_RAMP) - 1)]
        num_fill = NUMERAL_RAMP[min(i, len(NUMERAL_RAMP) - 1)]

        # base band
        add_rect(slide, x, ty, w, tier_h, fill=tint)
        # numeral block
        add_rect(slide, x, ty, num_col_w, tier_h, fill=num_fill)
        add_text(slide, x, ty, num_col_w, tier_h, tier["number"],
                 size=26, bold=True, color=WHITE,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        # title
        add_text(slide, main_x + 0.20, ty + 0.10, main_w, 0.36,
                 tier["title"], size=14, bold=True, color=PURPLE_PLUM)
        # body
        add_text(slide, main_x + 0.20, ty + 0.46, main_w, tier_h - 0.50,
                 tier["body"], size=10, color=BLACK)

        # example column (optional)
        if "example" in tier:
            ex_x = x + w - ex_col_w
            add_text(slide, ex_x, ty + 0.10, ex_col_w - 0.10, 0.30,
                     "IN PRACTICE", size=8, bold=True, color=PURPLE_DEEP)
            add_text(slide, ex_x, ty + 0.40, ex_col_w - 0.10,
                     tier_h - 0.46, tier["example"],
                     size=9.5, italic=True, color=DARK_GRAY)


def swimlane_row(slide, x, y, w, h, *,
                 letter, name, input_text, steps, output_text,
                 band_fill=NEUTRAL_LIGHT, chip_colors=None):
    """Skill §6.16 — one row of a synchronized swimlane pipeline.

    Args:
        steps: list of (actor_name, work_description) tuples
        chip_colors: optional dict mapping actor_name → RGBColor.
            If not provided, colors are assigned in order of first appearance
            from the palette ring: PURPLE_PRIMARY, PURPLE_DEEP, PURPLE_PLUM,
            then cycles.
    """
    add_rect(slide, x, y, w, h, fill=band_fill)

    # letter disc
    disc_d = 0.55
    add_oval(slide, x + 0.13, y + (h - disc_d) / 2, disc_d, disc_d, PURPLE_PLUM)
    add_text(slide, x + 0.13, y + (h - disc_d) / 2, disc_d, disc_d, letter,
             size=16, bold=True, color=WHITE,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

    # name + input
    name_x = x + 0.83
    name_w = 2.65
    add_text(slide, name_x, y + 0.10, name_w, 0.30, name,
             size=12, bold=True, color=PURPLE_PLUM)
    add_text(slide, name_x, y + 0.42, name_w, h - 0.50, input_text,
             size=9, color=DARK_GRAY)

    # output column
    out_w = 2.14
    out_x = x + w - out_w
    chip_h = 0.62
    chip_y = y + (h - chip_h) / 2
    add_rect(slide, out_x, chip_y, out_w, chip_h, fill=LAVENDER)
    add_text(slide, out_x + 0.10, chip_y + 0.06, out_w - 0.20, 0.22,
             "OUTPUT", size=7.5, bold=True, color=PURPLE_DEEP)
    add_text(slide, out_x + 0.10, chip_y + 0.26, out_w - 0.20, 0.34,
             output_text, size=8.5, bold=True, color=PURPLE_PLUM)

    # pipeline chips between name and output
    flow_x = name_x + name_w + 0.20
    flow_w = out_x - flow_x - 0.20
    nsteps = len(steps)
    arrow_w = 0.22
    chip_w = (flow_w - (nsteps - 1) * arrow_w) / nsteps

    # build chip-color assignment: caller-provided dict wins; otherwise auto-assign
    # in order of first appearance from PURPLE_PRIMARY → PURPLE_DEEP → PURPLE_PLUM (cycles).
    palette_ring = [PURPLE_PRIMARY, PURPLE_DEEP, PURPLE_PLUM]
    resolved_colors = dict(chip_colors) if chip_colors else {}
    seen_order = []
    for actor, _ in steps:
        if actor not in resolved_colors and actor not in seen_order:
            seen_order.append(actor)
    for idx, actor in enumerate(seen_order):
        resolved_colors[actor] = palette_ring[idx % len(palette_ring)]

    for j, (actor, work) in enumerate(steps):
        cx = flow_x + j * (chip_w + arrow_w)
        chip_fill = resolved_colors.get(actor, PURPLE_PLUM)
        add_rect(slide, cx, chip_y, chip_w, chip_h, fill=chip_fill)
        add_text(slide, cx + 0.08, chip_y + 0.06, chip_w - 0.16, 0.26,
                 actor, size=9, bold=True, color=WHITE)
        add_text(slide, cx + 0.08, chip_y + 0.30, chip_w - 0.16, 0.30,
                 work, size=8, color=LAVENDER_2)
        if j < nsteps - 1:
            ax = cx + chip_w + 0.02
            add_text(slide, ax, chip_y, arrow_w, chip_h, "▸",
                     size=14, bold=True, color=PURPLE_PRIMARY,
                     align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)


# ────────────────────────────────────────────────────────────────────
# Hero SVG pipeline (design-system.md §14, §19)
# ────────────────────────────────────────────────────────────────────

def rasterize_svg(svg_string, output_path, *, width=2560):
    """Rasterize a hero SVG string to PNG at >= 2x resolution.

    The SVG MUST carry marks only — no <text> elements. All labels go in
    as native text via add_text() after the image is placed.

    Author the SVG at the exact aspect ratio of the pptx rectangle it will
    fill (not always 1280x720). A body exhibit at w:12.33, h:5.0 in is
    ~2.47:1, so author that SVG at ~1234x500, render at width=2560.

    Tries in order:
      1. cairosvg  — pip install cairosvg (preferred, full SVG support)
      2. Raises RuntimeError with install guidance.
    If neither is available, fall back to headless Chrome:
      chromium --headless --screenshot --window-size=<width>,<height> file.svg

    Args:
        svg_string: SVG markup as a Python string.
        output_path: destination PNG path (str or pathlib.Path).
        width: output pixel width (default 2560 for 2x on a 1280-wide slot).
    """
    try:
        import cairosvg
        cairosvg.svg2png(
            bytestring=svg_string.encode(),
            write_to=str(output_path),
            output_width=width,
        )
        return
    except ImportError:
        pass
    raise RuntimeError(
        "cairosvg is required to rasterize hero SVGs.\n"
        "Install:  pip install cairosvg\n"
        "Alternatively render with headless Chrome:\n"
        "  chromium --headless --screenshot --window-size=2560,<height> hero.svg"
    )


def add_image(slide, path, x, y, w, h):
    """Place one rasterized exhibit image on a slide.

    One call per exhibit — never call this multiple times for fragments of
    a single visual (that produces the 'compressed / low-fidelity' look).
    Every label over the image must be added as native text via add_text()
    at the anchor computed by hero_label_xy().

    Args:
        slide: python-pptx slide object.
        path: path to PNG/JPG (str or pathlib.Path).
        x, y, w, h: position and size in inches.
    """
    slide.shapes.add_picture(str(path), Inches(x), Inches(y), Inches(w), Inches(h))


def hero_label_xy(img_x, img_y, img_w, img_h, cx_px, cy_px, *,
                  svg_w=1280, svg_h=720):
    """Convert an SVG pixel anchor to pptx inches for a native text label.

    Use this to place a native text box exactly at the point in the hero
    image where a label should appear. The SVG carries no text; every label
    is placed afterward as a native add_text() call.

    Args:
        img_x, img_y, img_w, img_h: the image position/size in pptx inches.
        cx_px, cy_px: the target point in SVG pixel coordinates.
        svg_w, svg_h: SVG canvas dimensions (match the SVG's width/height attrs).

    Returns:
        (x, y) in pptx inches — the centre-point of the label target.

    Usage:
        lx, ly = hero_label_xy(0.5, 1.5, 12.33, 5.0, cx_px=800, cy_px=160,
                                svg_w=1234, svg_h=500)
        # Center a text box of width 1.8 on that point:
        add_text(slide, lx - 0.9, ly - 0.15, 1.8, 0.30, "Label", size=12, ...)
    """
    x = img_x + (cx_px / svg_w) * img_w
    y = img_y + (cy_px / svg_h) * img_h
    return x, y


def portfolio_2x2(slide, x, y, w, h, *,
                  x_axis_low, x_axis_high,
                  y_axis_low, y_axis_high,
                  q_labels, dots,
                  tint_side="left",
                  dot_size=0.35):
    """Skill §6.4 — 2x2 portfolio landscape with plotted dots.

    Args:
        x_axis_low/high: axis labels for left and right ends (caller supplies arrows)
        y_axis_low/high: axis labels for bottom and top ends
        q_labels: dict with keys 'tl','tr','bl','br' for quadrant labels
        dots: list of (x_frac, y_frac, number, color)
            x_frac: 0=left, 1=right; y_frac: 0=bottom, 1=top
        tint_side: "left", "right", or "none" — which half to tint pale lavender
        dot_size: square dot size in inches (squares-not-circles brand rule)
    """
    add_rect(slide, x, y, w, h, fill=NEUTRAL_LIGHT)
    # tint one half to differentiate quadrant zones
    if tint_side == "left":
        add_rect(slide, x, y, w / 2, h, fill=RGBColor.from_string("F4ECFF"))
    elif tint_side == "right":
        add_rect(slide, x + w / 2, y, w / 2, h, fill=RGBColor.from_string("F4ECFF"))

    mid_x = x + w / 2
    mid_y = y + h / 2
    add_line(slide, mid_x, y, 0, h, DIVIDER, weight=0.75)
    add_line(slide, x, mid_y, w, 0, DIVIDER, weight=0.75)

    # quadrant labels
    label_w = w / 2 - 0.30
    add_text(slide, x + 0.15, y + 0.10, label_w, 0.24,
             q_labels.get("tl", ""), size=8, bold=True, color=LABEL_GRAY)
    add_text(slide, mid_x + 0.15, y + 0.10, label_w, 0.24,
             q_labels.get("tr", ""), size=8, bold=True, color=PURPLE_DEEP)
    add_text(slide, x + 0.15, mid_y + 0.10, label_w, 0.24,
             q_labels.get("bl", ""), size=8, bold=True, color=LABEL_GRAY)
    add_text(slide, mid_x + 0.15, mid_y + 0.10, label_w, 0.24,
             q_labels.get("br", ""), size=8, bold=True, color=PURPLE_DEEP)

    # axis labels — caller supplies arrows / decorations
    add_text(slide, x - 1.15, mid_y - 0.20, 1.10, 0.40,
             y_axis_high, size=8, bold=True, color=LABEL_GRAY,
             align=PP_ALIGN.RIGHT)
    add_text(slide, x - 1.15, y + h - 0.40, 1.10, 0.40,
             y_axis_low, size=8, bold=True, color=LABEL_GRAY,
             align=PP_ALIGN.RIGHT)
    add_text(slide, x - 0.10, y + h + 0.05, 2.40, 0.28,
             x_axis_low, size=8, bold=True, color=LABEL_GRAY)
    add_text(slide, x + w - 2.40, y + h + 0.05, 2.40, 0.28,
             x_axis_high, size=8, bold=True, color=PURPLE_DEEP,
             align=PP_ALIGN.RIGHT)

    # plot dots — squares per Accenture brand rule (squares-not-circles)
    for fx, fy, num, color in dots:
        cx = x + fx * w - dot_size / 2
        cy = y + (1 - fy) * h - dot_size / 2
        add_rect(slide, cx, cy, dot_size, dot_size, fill=color)
        add_text(slide, cx, cy, dot_size, dot_size, num,
                 size=10, bold=True, color=WHITE,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)


# ────────────────────────────────────────────────────────────────────
# Extended archetype builders — skill §6 (cover, runway, board, mosaic, etc.)
# ────────────────────────────────────────────────────────────────────

def editorial_cover_split(slide, *,
                          left_label, title, subtitle,
                          right_accent_label="",
                          split_at=5.80):
    """Skill §6.26 — cover: deep plum left panel, neutral-light right field.

    Args:
        left_label: small-caps utility label above the title
        title: main headline (large, white on plum)
        subtitle: strapline / date line below headline
        right_accent_label: optional label shown on right panel
        split_at: x-position of panel split in inches (default 5.80)
    """
    # left panel
    add_rect(slide, 0, 0, split_at, SLIDE_H, fill=PURPLE_PLUM)
    add_rect(slide, 0, 0, split_at, 0.18, fill=PURPLE_PRIMARY)
    if left_label:
        add_text(slide, 0.42, 0.30, split_at - 0.60, 0.28, left_label.upper(),
                 size=8, bold=True, color=LAVENDER)
    add_text(slide, 0.42, 1.20, split_at - 0.60, 3.20, title,
             size=28, bold=True, color=WHITE)
    add_text(slide, 0.42, 4.60, split_at - 0.60, 1.60, subtitle,
             size=12, color=LAVENDER_2)
    add_text(slide, 0.42, 7.10, 2.0, 0.28, "Accenture",
             size=10, bold=True, color=LAVENDER)
    # right panel
    add_rect(slide, split_at, 0, SLIDE_W - split_at, SLIDE_H, fill=NEUTRAL_LIGHT)
    add_rect(slide, split_at, 0, SLIDE_W - split_at, 0.18, fill=PURPLE_PRIMARY)
    right_x = split_at + 0.05
    right_w = SLIDE_W - right_x
    add_rect(slide, right_x, 1.20, right_w - 0.50, 4.80,
             fill=RGBColor.from_string("F4ECFF"))
    add_rect(slide, split_at + 0.05, 1.20, 0.12, 4.80, fill=PURPLE_PRIMARY)
    if right_accent_label:
        add_text(slide, right_x + 0.30, 1.40, right_w - 0.80, 0.36,
                 right_accent_label, size=10, bold=True, color=PURPLE_PLUM)


def hero_signal_wall(slide, x, y, w, h, *,
                     stat, stat_label, context,
                     chips=None,
                     field_fill=None):
    """Skill §6.27 — dominant single stat + label + context + chip row.

    Args:
        stat: large metric (e.g. "87%", "3.2×")
        stat_label: label line below the stat
        context: supporting paragraph
        chips: optional list of (label, fill_color) tuples
        field_fill: background fill color (default NEUTRAL_LIGHT)
    """
    if field_fill is None:
        field_fill = NEUTRAL_LIGHT
    add_rect(slide, x, y, w, h, fill=field_fill)
    add_rect(slide, x, y, w, 0.14, fill=PURPLE_PRIMARY)
    stat_y = y + h * 0.18
    add_text(slide, x + 0.30, stat_y, w - 0.60, h * 0.40, stat,
             size=72, bold=True, color=PURPLE_PLUM,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    label_y = stat_y + h * 0.40
    add_text(slide, x + 0.30, label_y, w - 0.60, 0.36, stat_label,
             size=13, bold=True, color=PURPLE_DEEP, align=PP_ALIGN.CENTER)
    ctx_y = label_y + 0.42
    add_text(slide, x + 0.40, ctx_y, w - 0.80, h - (ctx_y - y) - 0.60,
             context, size=10.5, color=DARK_GRAY, align=PP_ALIGN.CENTER)
    if chips:
        chip_h = 0.44
        chip_y = y + h - chip_h - 0.22
        n = len(chips)
        chip_w = (w - 0.40 - (n - 1) * 0.10) / n
        for i, (chip_label, chip_color) in enumerate(chips):
            cx = x + 0.20 + i * (chip_w + 0.10)
            add_chip(slide, cx, chip_y, chip_w, chip_h,
                     fill=chip_color, text=chip_label, size=9)


def transformation_runway(slide, x, y, w, h, *,
                          phases, workstreams,
                          phase_h=0.52):
    """Skill §6.8 — phase header band + horizontal workstream lanes + milestones.

    Args:
        phases: list of (label, width_fraction) tuples summing to 1.0
                e.g. [("Foundation", 0.25), ("Scale", 0.40), ("Sustain", 0.35)]
        workstreams: list of dicts — keys: name (str), milestones (list of
                     (phase_index, label) tuples, 0-based)
        phase_h: height of the phase header band in inches
    """
    n_streams = len(workstreams)
    lane_h = (h - phase_h - 0.10) / max(n_streams, 1)
    # phase header
    add_rect(slide, x, y, w, phase_h, fill=PURPLE_PLUM)
    px = x
    phase_xs = []
    for i, (phase_label, frac) in enumerate(phases):
        pw = w * frac
        phase_xs.append((px, pw))
        if i > 0:
            add_line(slide, px, y, 0, phase_h, WHITE, weight=0.75)
        add_text(slide, px + 0.12, y + 0.10, pw - 0.24, phase_h - 0.12,
                 phase_label, size=10, bold=True, color=WHITE,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        px += pw
    # workstream lanes
    for si, ws in enumerate(workstreams):
        ly = y + phase_h + 0.10 + si * lane_h
        band_fill = TINT_RAMP[min(si, len(TINT_RAMP) - 1)]
        add_rect(slide, x, ly, w, lane_h - 0.06, fill=band_fill)
        add_text(slide, x + 0.14, ly + 0.10, 1.60, lane_h - 0.20,
                 ws["name"], size=9.5, bold=True, color=PURPLE_PLUM)
        for phase_idx, m_label in ws.get("milestones", []):
            if phase_idx < len(phase_xs):
                ph_x, ph_w = phase_xs[phase_idx]
                mx = ph_x + ph_w / 2
                my = ly + lane_h / 2 - 0.18
                add_rect(slide, mx - 0.16, my, 0.30, 0.30, fill=PURPLE_PRIMARY)
                add_text(slide, mx - 0.90, my + 0.34, 1.80, 0.26,
                         m_label, size=7.5, color=PURPLE_PLUM,
                         align=PP_ALIGN.CENTER)


def blueprint_board(slide, x, y, w, h, *,
                    layers, tiles_per_row=4):
    """Skill §6.12 — horizontal tonal bands (layers) + tile grid per layer.

    Args:
        layers: list of dicts — keys: label (str), tiles (list of str),
                fill (optional RGBColor, defaults to TINT_RAMP escalation)
        tiles_per_row: max tiles shown per layer (default 4)
    """
    n = len(layers)
    layer_h = (h - (n - 1) * 0.06) / max(n, 1)
    label_w = 1.60
    label_fills = [PURPLE_PLUM, PURPLE_DEEP, LABEL_GRAY,
                   LABEL_GRAY, LABEL_GRAY, LABEL_GRAY]
    for i, layer in enumerate(layers):
        ly = y + i * (layer_h + 0.06)
        lyr_fill = layer.get("fill", TINT_RAMP[min(n - 1 - i, len(TINT_RAMP) - 1)])
        add_rect(slide, x, ly, w, layer_h, fill=lyr_fill)
        lbl_fill = label_fills[min(i, len(label_fills) - 1)]
        add_rect(slide, x, ly, label_w, layer_h, fill=lbl_fill)
        add_text(slide, x + 0.10, ly, label_w - 0.10, layer_h, layer["label"],
                 size=9, bold=True, color=WHITE,
                 anchor=MSO_ANCHOR.MIDDLE, align=PP_ALIGN.CENTER)
        tiles = layer.get("tiles", [])
        tile_area_x = x + label_w + 0.18
        tile_area_w = w - label_w - 0.28
        nt = min(len(tiles), tiles_per_row)
        if nt:
            tile_w = (tile_area_w - (nt - 1) * 0.10) / nt
            tile_h = layer_h - 0.28
            for j, tile_label in enumerate(tiles[:nt]):
                tx = tile_area_x + j * (tile_w + 0.10)
                ty = ly + 0.14
                add_rect(slide, tx, ty, tile_w, tile_h,
                         fill=WHITE, line=DIVIDER, line_w=0.5)
                add_text(slide, tx + 0.10, ty + 0.06, tile_w - 0.20,
                         tile_h - 0.12, tile_label, size=9, color=PURPLE_PLUM)


def recommendation_stack(slide, x, y, w, h, *,
                         rows, highlight_idx=0,
                         anchor_title="", anchor_body="",
                         anchor_w=3.20):
    """Skill §6.25 — numbered recommendation rows + optional right anchor panel.

    Args:
        rows: list of dicts — keys: number (str), title (str), body (str)
        highlight_idx: which row to highlight in lavender (0-based)
        anchor_title: header for the right anchor panel (omit to suppress panel)
        anchor_body: body text for the right anchor panel
        anchor_w: width of anchor panel in inches
    """
    main_w = w - anchor_w - 0.20 if anchor_title else w
    n = len(rows)
    gap = 0.06
    row_h = (h - (n - 1) * gap) / max(n, 1)
    for i, row in enumerate(rows):
        ry = y + i * (row_h + gap)
        is_hl = (i == highlight_idx)
        add_rect(slide, x, ry, main_w, row_h,
                 fill=LAVENDER if is_hl else NEUTRAL_LIGHT)
        num_w = 0.72
        add_rect(slide, x, ry, num_w, row_h,
                 fill=PURPLE_PRIMARY if is_hl else PURPLE_PLUM)
        add_text(slide, x, ry, num_w, row_h, row["number"],
                 size=18, bold=True, color=WHITE,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        tc = PURPLE_PLUM if is_hl else BLACK
        add_text(slide, x + num_w + 0.16, ry + 0.08,
                 main_w - num_w - 0.26, 0.34,
                 row["title"], size=12, bold=True, color=tc)
        add_text(slide, x + num_w + 0.16, ry + 0.42,
                 main_w - num_w - 0.26, row_h - 0.48,
                 row.get("body", ""), size=9.5, color=DARK_GRAY)
    if anchor_title:
        ax = x + main_w + 0.20
        add_rect(slide, ax, y, anchor_w, h, fill=PURPLE_PLUM)
        add_text(slide, ax + 0.18, y + 0.18, anchor_w - 0.36, 0.36,
                 anchor_title, size=10, bold=True, color=LAVENDER)
        add_rect(slide, ax + 0.18, y + 0.60, anchor_w - 0.36, 0.03,
                 fill=LAVENDER)
        add_text(slide, ax + 0.18, y + 0.70, anchor_w - 0.36, h - 0.80,
                 anchor_body, size=9.5, color=LAVENDER_2)


def closed_loop_orbit(slide, x, y, w, h, *,
                      hub_label, hub_sublabel="",
                      segments):
    """Skill §6.6 — central hub + surrounding segment tiles + connector lines.

    Segments are placed in a radial layout using native rectangles — WORKHORSE.

    Args:
        hub_label: center label (e.g. system or process name)
        hub_sublabel: secondary line inside hub
        segments: list of (label, body) tuples — 4 to 6 work best
    """
    cx = x + w / 2
    cy = y + h / 2
    hub_r = min(w, h) * 0.16
    orbit_r = min(w, h) * 0.38
    hub_d = hub_r * 2
    # hub square
    add_rect(slide, cx - hub_r, cy - hub_r, hub_d, hub_d, fill=PURPLE_PLUM)
    add_text(slide, cx - hub_r, cy - hub_r, hub_d, hub_d * 0.60,
             hub_label, size=11, bold=True, color=WHITE,
             align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    if hub_sublabel:
        add_text(slide, cx - hub_r, cy, hub_d, hub_d * 0.40,
                 hub_sublabel, size=8, color=LAVENDER,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.TOP)
    # segments
    n = len(segments)
    seg_w = min(w, h) * 0.26
    seg_h = min(w, h) * 0.18
    seg_fills = [PURPLE_PRIMARY, PURPLE_DEEP, PURPLE_PLUM,
                 RGBColor.from_string("D7BFFF"), LAVENDER, NEUTRAL_LIGHT]
    seg_tc = [WHITE, WHITE, WHITE, PURPLE_PLUM, PURPLE_PLUM, PURPLE_PLUM]
    for i, (seg_label, seg_body) in enumerate(segments):
        angle = math.radians(90 + i * 360 / n)
        sx = cx + orbit_r * math.cos(angle) - seg_w / 2
        sy = cy - orbit_r * math.sin(angle) - seg_h / 2
        fill = seg_fills[i % len(seg_fills)]
        tc = seg_tc[i % len(seg_tc)]
        add_rect(slide, sx, sy, seg_w, seg_h, fill=fill)
        add_text(slide, sx + 0.10, sy + 0.07, seg_w - 0.20, 0.28,
                 seg_label, size=9.5, bold=True, color=tc)
        add_text(slide, sx + 0.10, sy + 0.35, seg_w - 0.20, seg_h - 0.40,
                 seg_body, size=8, color=tc)
        # connector from hub edge to segment centre
        edge_x = cx + (hub_r + 0.06) * math.cos(angle)
        edge_y = cy - (hub_r + 0.06) * math.sin(angle)
        add_line(slide, edge_x, edge_y,
                 (sx + seg_w / 2) - edge_x, (sy + seg_h / 2) - edge_y,
                 DIVIDER, weight=0.75)


def evidence_mosaic(slide, x, y, w, h, *,
                    stats, quote="", quote_source="",
                    n_cols=3):
    """Skill §6.3 — stat tile grid + optional quote pull panel on right.

    Args:
        stats: list of dicts — keys: value (str), label (str),
               sublabel (str, optional)
        quote: pull-quote text (shown in a right plum panel when non-empty)
        quote_source: attribution line for the quote
        n_cols: number of tile columns (default 3)
    """
    quote_w = 3.20 if quote else 0
    tile_area_w = w - quote_w - (0.20 if quote else 0)
    n = len(stats)
    n_rows = max((n + n_cols - 1) // n_cols, 1)
    gap = 0.08
    tile_w = (tile_area_w - (n_cols - 1) * gap) / n_cols
    tile_h = (h - (n_rows - 1) * gap) / n_rows
    tile_fills = [NEUTRAL_LIGHT, LAVENDER, LAVENDER_2]
    for i, stat in enumerate(stats):
        col = i % n_cols
        row = i // n_cols
        tx = x + col * (tile_w + gap)
        ty = y + row * (tile_h + gap)
        fill = tile_fills[i % len(tile_fills)]
        add_rect(slide, tx, ty, tile_w, tile_h, fill=fill)
        add_rect(slide, tx, ty, tile_w, 0.08, fill=PURPLE_PRIMARY)
        add_text(slide, tx + 0.14, ty + 0.16, tile_w - 0.28, tile_h * 0.50,
                 stat["value"], size=28, bold=True, color=PURPLE_PLUM)
        add_text(slide, tx + 0.14, ty + tile_h * 0.60, tile_w - 0.28,
                 tile_h * 0.28, stat["label"], size=9, bold=True, color=BLACK)
        if stat.get("sublabel"):
            add_text(slide, tx + 0.14, ty + tile_h * 0.80, tile_w - 0.28,
                     tile_h * 0.18, stat["sublabel"],
                     size=7.5, italic=True, color=LABEL_GRAY)
    if quote:
        qx = x + tile_area_w + 0.20
        add_rect(slide, qx, y, quote_w, h, fill=PURPLE_PLUM)
        add_rect(slide, qx, y, quote_w, 0.12, fill=PURPLE_PRIMARY)
        add_text(slide, qx + 0.20, y + 0.24, quote_w - 0.40, h - 0.70,
                 f'"{quote}"', size=11, italic=True, color=WHITE)
        if quote_source:
            add_text(slide, qx + 0.20, y + h - 0.46, quote_w - 0.40, 0.34,
                     f"— {quote_source}", size=8.5, bold=True, color=LAVENDER)
