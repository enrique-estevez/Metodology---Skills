"""
Math-only geometry checker. Run BEFORE rendering to PNG to catch the
common failure modes (out-of-bounds shapes, footer collisions, text
overflow from neighbors) without spending tokens on image previews.

Usage:
    python verify_geometry.py path/to/deck.pptx

Exits 0 if all slides pass, 1 otherwise. Prints per-slide warnings.

Rules checked (skill §10, §18, §19):
  - shape extends beyond slide bounds (13.333 × 7.5)
  - shape collides with footer band (y ≥ 7.10)
  - shape collides with the header band (overlaps title region 0.0–1.50)
  - two shapes with text both occupy the same exact rectangle (overlap test)
  - text shape height < 0.15 (likely cropped)
  - text shape width < 0.10 (likely cropped)
  - large-font text (≥20pt) estimated to wrap beyond its declared height into a
    shape below it (TEXT-REFLOW-COLLISION — heuristic, conservative)
"""
import sys
import math
import argparse

if sys.stdout.encoding != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

from pptx import Presentation

SLIDE_W = 13.333
SLIDE_H = 7.5
FOOTER_Y = 7.10
HEADER_BOTTOM = 1.50  # below the motif rail


def bbox(sh):
    x = sh.left / 914400 if sh.left is not None else 0
    y = sh.top / 914400 if sh.top is not None else 0
    w = sh.width / 914400 if sh.width is not None else 0
    h = sh.height / 914400 if sh.height is not None else 0
    return x, y, w, h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    args = ap.parse_args()

    p = Presentation(args.path)
    sw = p.slide_width / 914400
    sh_ = p.slide_height / 914400

    total_issues = 0

    for i, slide in enumerate(p.slides, 1):
        issues = []
        shapes_with_text = []

        for shape in slide.shapes:
            x, y, w, h = bbox(shape)
            has_text = shape.has_text_frame and shape.text_frame.text.strip()
            label = (shape.text_frame.text.strip()[:40] + "…"
                     if has_text and len(shape.text_frame.text.strip()) > 40
                     else (shape.text_frame.text.strip() if has_text else "<no-text>"))

            # bounds
            if x < -0.01 or y < -0.01:
                issues.append(f"  OUT-OF-BOUNDS (neg): @({x:.2f},{y:.2f}) {label!r}")
            if x + w > sw + 0.01:
                issues.append(f"  OUT-OF-BOUNDS (right): right={x+w:.2f} > {sw:.2f} {label!r}")
            if y + h > sh_ + 0.01:
                issues.append(f"  OUT-OF-BOUNDS (bottom): bot={y+h:.2f} > {sh_:.2f} {label!r}")

            # footer collision (only for non-footer shapes)
            if has_text and y + h > FOOTER_Y and y < FOOTER_Y - 0.05:
                # shape straddles the footer line
                issues.append(f"  FOOTER-COLLISION: @({x:.2f},{y:.2f}) bot={y+h:.2f} {label!r}")

            # tiny text boxes likely cropped
            if has_text:
                if h < 0.15:
                    issues.append(f"  TINY-HEIGHT ({h:.2f}): {label!r}")
                if w < 0.10:
                    issues.append(f"  TINY-WIDTH ({w:.2f}): {label!r}")
                # read font size from first run of first paragraph (may be None)
                font_pt = None
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.size is not None:
                            font_pt = run.font.size.pt
                            break
                    if font_pt is not None:
                        break
                shapes_with_text.append(
                    (x, y, w, h, label, font_pt, shape.text_frame.text.strip())
                )

        # text-on-text overlap (same rectangle within tolerance)
        for a in range(len(shapes_with_text)):
            for b in range(a + 1, len(shapes_with_text)):
                ax, ay, aw, ah, alab, _, _ = shapes_with_text[a]
                bx, by, bw, bh, blab, _, _ = shapes_with_text[b]
                if (abs(ax - bx) < 0.05 and abs(ay - by) < 0.05
                        and abs(aw - bw) < 0.05 and abs(ah - bh) < 0.05):
                    # exact-overlap is intentional (icon+text), skip
                    continue
                # partial overlap of substantial text boxes
                ox = max(0, min(ax + aw, bx + bw) - max(ax, bx))
                oy = max(0, min(ay + ah, by + bh) - max(ay, by))
                if ox > 0.20 and oy > 0.10 and aw > 0.5 and bw > 0.5:
                    issues.append(
                        f"  TEXT-OVERLAP ({ox:.2f}×{oy:.2f}): "
                        f"{alab!r} ⨯ {blab!r}"
                    )

        # TEXT-REFLOW-COLLISION: estimate wrapped height for large-font boxes (≥20pt)
        # Heuristic — conservative to over-flag rather than miss headline/strapline pairs.
        # Note: use smw/smh (not sw/sh) to avoid shadowing the slide-dimension variables.
        for sx, sy, smw, smh, slab, sfont, stxt in shapes_with_text:
            if sfont is None or sfont < 20:
                continue
            chars_per_line = max(1, smw * 96 / (sfont * 0.55))
            lines = math.ceil(len(stxt) / chars_per_line)
            est_h = lines * sfont * 1.2 / 72
            if est_h <= smh + 0.05:
                continue  # text fits within declared height
            est_bottom = sy + est_h
            for bx, by, bw, bh, blab, _, _ in shapes_with_text:
                if by <= sy:
                    continue
                if by >= est_bottom:
                    continue
                horiz_overlap = min(sx + smw, bx + bw) - max(sx, bx)
                if horiz_overlap > 0.20:
                    issues.append(
                        f"  TEXT-REFLOW-COLLISION: {slab!r} "
                        f"est_bottom={est_bottom:.2f} (declared {sy+smh:.2f}) "
                        f"overflows into {blab!r} at y={by:.2f}"
                    )
                    break  # one warning per overflowing shape

        if issues:
            print(f"\n— SLIDE {i} — {len(issues)} issue(s):")
            for line in issues:
                print(line)
            total_issues += len(issues)
        else:
            print(f"— SLIDE {i} — clean")

    print("\n" + "=" * 60)
    if total_issues == 0:
        print("PASS — geometry clean across all slides")
        sys.exit(0)
    else:
        print(f"FAIL — {total_issues} issue(s) across the deck")
        sys.exit(1)


if __name__ == "__main__":
    main()
