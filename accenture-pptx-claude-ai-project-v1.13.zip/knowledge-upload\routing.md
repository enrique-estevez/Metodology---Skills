# Story-to-visual routing & archetype library

Read when planning the visual for **each slide**.

## 5. Routing engine

### 5.1 Routing rule
For every non-appendix slide:
1. Identify the slide's message type
2. Generate at least three candidate visual routes
3. Ensure the route set is not all rectangle-led
4. Choose the strongest route based on clarity, distinctiveness, executive fit, premium finish potential
5. Only then begin detailed construction

### 5.2 Candidate route generation
Each concept: short name, primary graphic object, why it fits, why better than box-card fallback, whether chart-led, image-led, system-led, or composition-led.

### 5.3 Route-set composition
Where relevant: one clearest analytic/chart-led option · one strongest non-rectilinear option that still feels consulting-safe · one route testing imagery/screenshots/complex board. Do not generate three versions of the same card grid.

### 5.4 Quantitative claims must test a chart route first
If the message depends on trend, spread, concentration, sequencing, comparison, gap over time, or decomposition of value — test a chart or axis-based route before tiles or bullets.

### 5.5 Image-led and complex-board routes
Legitimate when increasing credibility — annotated screenshot-like board, image + callout field, image-emulating hero field, panorama/ecosystem board, layered blueprint.

### 5.6 Message types → preferred visual routes

| Message type | Use first | Avoid as default |
|---|---|---|
| **Cover / opener / framing** | editorial cover split · hero signal wall · premium transition field · image-led title field · large-typography opener with one organizing geometry | plain title slide with decorative purple block |
| **Shift / before-after** | transition bridge · split-screen model shift · from-to staircase · collapsing old-to-new lens · contrasted value-chain overlays · diagonal/progressive band evolution | two plain text boards with FROM/TO labels |
| **Value at stake / economics / why now** | benchmark chart with highlighted spread · indexed trajectories · waterfall/value bridge · value-pool landscape · evidence mosaic · growth/gap curve with callouts | isolated KPI tiles with no analytic backbone |
| **Where to play / portfolio / prioritization** | portfolio map · 2x2 / 2x3 risk-value landscape · staged adoption spectrum · deployment wedges · prioritization staircase · maturity vs control matrix | three equal cards describing options |
| **How it works / operating loop** | closed-loop diagram · layered control stack · flow map with feedback · control-tower hub with rails · sense-plan-act-reflect orbit | four boxes and arrows with no system depth |
| **Path forward / roadmap** | transformation runway · phase journey with gates · capability ladder across time · layered roadmap with enabling rails · maturity progression with dependencies | table of phases and bullets |
| **Operating model / governance** | control and decision-rights stack · governance operating model blueprint · human-on-the-loop supervision · federated vs centralized role map · pods/lanes with escalation logic | organogram without functional logic |
| **Capability model / enablers** | layered foundation stack · house model · platform and control stack · capability ladder · dependency ladder with sequencing cues | six equal columns of text |
| **Case study / proof / credibility** | split case-study field with quantified outcomes · before/after evidence board · one strong image or system screenshot with callouts · proof ribbon anchored by one metric cluster | a paragraph plus three floating numbers |
| **Closing / thank you / discussion** | discussion close anchored by one decisive line · premium thank-you page with motif continuation · final recommendation/action slide with restrained close | blank page with centered "Thank you" |

### 5.7 Tie-break (in order)
makes the point fastest · most distinctive page silhouette · fits the mode and audience · avoids box-card dependence · supports elegant density · strongest chart/image/system logic · contributes variety relative to neighbors.

---

## 6. Graphic archetype library

Each archetype is a legitimate, reusable page logic. Builders for the most common four are in `lib/acn_pptx_utils.py` (`transition_bridge`, `layered_stack`, `swimlane_row`, `portfolio_2x2`).

| # | Archetype | Use for |
|---|---|---|
| 6.1 | **Transition bridge** | Moving from current to future state. Left=old, right=new, center=mechanism of shift |
| 6.2 | **Indexed trajectory chart** | Leadership/adoption gap, economics over time, winner-takes-more |
| 6.3 | **Evidence mosaic** | Proof pages where multiple signals support a conclusion |
| 6.4 | **Portfolio landscape** | Where to play, prioritization, value-vs-risk/readiness |
| 6.5 | **Wedge spectrum** | Staged evolution, bounded-to-autonomous progression |
| 6.6 | **Closed-loop orbit** | Agentic systems, control loops, management systems |
| 6.7 | **Layered control stack** | Capabilities, architecture, governance, enablers |
| 6.8 | **Transformation runway** | Phased journey, time-based capability build, op-model transition |
| 6.9 | **Decision tree / branching path** | Decision logic, strategic options, when-to-play criteria |
| 6.10 | **House model** | Strategy/operating model — only when house metaphor truly fits |
| 6.11 | **Staircase / maturity ladder** | Scale journeys, progressive maturity |
| 6.12 | **Blueprint board** | Architecture, target state, layered ecosystem views |
| 6.13 | **Ecosystem map** | Partner landscape, stakeholder network |
| 6.14 | **Command-center hub** | Governance, operating committee, control tower |
| 6.15 | **Insight ribbon** | Sequential insights/themes across the page |
| 6.16 | **Synchronized swimlanes** | Functions, role handoffs, operating processes |
| 6.17 | **Annotated artifact** | When a screenshot/board/product view carries credibility |
| 6.18 | **Split case-study field** | Case study, proof, credentials |
| 6.19 | **Value bridge** | Where value comes from, economics decomposition |
| 6.20 | **Radar (with discipline)** | Only when comparing balanced dimensions |
| 6.21 | **Chord/flow relational map** | Cross-functional dependencies (only if exec-readable) |
| 6.22 | **Layered evidence wall** | Benchmark data, quotes, examples, implications |
| 6.23 | **Pyramid (with caution)** | Only when hierarchy is the story |
| 6.24 | **Signal-to-action board** | Trend → implication → response logic |
| 6.25 | **Recommendation stack** | What the board should approve or sequence |
| 6.26 | **Editorial cover split** | Standalone executive opener, section opener |
| 6.27 | **Hero signal wall** | Opening with several signals/themes/value cues |
| 6.28 | **Premium benchmark field** | Proof pages where a chart should dominate |
| 6.29 | **Annotated panorama / image-led board** | System context, operations environment |
| 6.30 | **Spotlight decision field** | Choice architecture, illuminating one critical zone |
| 6.31 | **Multi-rail operating poster** | Integrated operating model, platform + controls + value flow |
| 6.32 | **Premium closing discussion page** | Final page before Q&A or close |
| 6.33 | **Elegant thank-you close** | Formal client-ready close |
