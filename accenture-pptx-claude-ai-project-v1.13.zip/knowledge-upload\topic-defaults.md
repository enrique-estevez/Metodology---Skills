# Motif, beautification, topic defaults

Read selectively — motif (§7) at planning time, beautification (§8) during the art-direction pass, topic defaults (§17) only for AI/agentic decks.

## 7. Deck motif system

### 7.1 Choose one motif up front
Examples: split chevrons · orbital rings · stacked planes · control rails · horizon arc · notched bands · bracket scaffolds · progressive wedges · node lattice · spotlight halo.

### 7.2 Use as a recurring graphic cue
Subtly in hero page, section labels, chart highlights, page accents. Never gimmicky.

### 7.3 Restrained continuity
No motif → unrelated pages. Too strong → over-designed. Aim for restrained continuity.

### 7.4 Motif families
Recurring icon-chip language · chart highlight logic carried across pages · image treatment logic (duotone or tonal crop) · one family of arcs/rails/brackets/halos · one recurring evidence-tag style.

### 7.5 Bookends echo the motif
Opener and closing page should echo the same motif family so the deck feels intentionally framed.

---

## 8. Beautification system

### 8.1 Consulting beauty
Clear silhouette · hierarchy of scale · disciplined tension · strong contrast · deliberate negative space · confident emphasis · integrated proof · limited but meaningful material variation · elegant transitions between type/data/icons/images/shapes.

### 8.2 Mandatory art-direction pass
After layout is correct, ask: authored or assembled? · strong focal point? · eye guided in a deliberate path? · enough contrast in scale, weight, density? · composed not just aligned? · any rectangle remain because it was the easiest to draw?

### 8.3 Premium-feel techniques
Asymmetric hero fields · layered tonal bands · selective dark-on-light contrast zones · strategic cropping · notched/bracketed headers · subtle gradient only on hero surfaces · large-number anchoring · spotlight emphasis · thin rule systems · callout rails or evidence tags integrated into the graphic · one large organizing background geometry · icon chips that anchor modules · one art-directed chart/image field rather than several weak small ones.

### 8.4 Functional iconography
**Rules**: one icon family only · simple monoline or geometric · small to medium · strictly grid-aligned · always paired with text · reduce text friction, not decorate empty space.
**Avoid**: oversized icons, consumer-app emoji feel, multiple icon styles, icons on every bullet, icons floating without purpose.

### 8.5 Chart and quantitative storytelling
**Use charts when**: trend over time, comparison among groups, leader-laggard spread, value concentration, economics decomposition, stage progression, prioritization across two measurable dimensions.
**Preferred families**: indexed line · slope/divergence · clustered bar with one hero series · lollipop or dot plot · waterfall/bridge · bubble or portfolio matrix · heat map with disciplined labeling · stacked bar only when composition is the story.
**Beautification**: reduce chart ink · keep axes minimal · direct-label where possible · highlight one lead series/bar/region/threshold · integrate callouts · dock supporting proof tightly · never paste a chart as if exported from Excel.

### 8.6 Premium proof pages, not tiled
One lead fact dominates · supported by one chart/bridge/benchmark · one or two secondary proof modules · vary scale · tonal rhythm rather than identical tiles · whitespace around lead fact.

### 8.7 Imagery and complex-board system
**Strong uses**: premium cover/section opener · case study · product/workflow evidence · operating environment context · architecture/system blueprint.
**Rules**: crop with intent · align image edges and overlays to grid · sparing precise overlays · prefer purposeful enterprise imagery over generic stock · when real imagery unavailable, emulate with layered geometry/texture/gradients/icon clusters/linework/labels · frame and annotate screenshots like evidence.

### 8.8 Non-rectilinear geometry palette
Arcs, rings, wedges, bands, rails, halos, stepped planes, scaffold brackets, disciplined diagonals, tapered pathways, node lattices, layered contours, spotlight fields. Must **organize meaning**, not just style it. One dominant non-rectilinear move at a time.

### 8.9 Elegance rules
Fewer but stronger surfaces · stronger type hierarchy · one clear area of visual gravity · less repetitive outlining · tighter language · better rhythm between large and small · subtle depth through tonal layering not shadow abuse.

### 8.10 Premium cover system
Establishes topic as important · feels more spacious and art-directed than interiors · uses one dominant visual surface (image field, split, wedge, arc, or signal wall) · title block intentional and docked · avoids template-placeholder feel · one strong composition move only · limited metadata · serious restrained palette · no empty dead space.

### 8.11 Premium closing
Good options: `Thank you` · `Discussion` · `Questions` · final action line · summary recommendation with elegant close.
Carry forward the deck motif · lighter than core content but still designed · avoid centered text on blank page · small contact/team line acceptable.

### 8.12 Beauty constraints
Never at the expense of readability, trust, business seriousness, density control, fidelity to the message, brand discipline.

---

## 17. Topic defaults: AI / agentic AI / data / automation

### 17.1 Default 5-slide story
1. **The shift** → from assistive AI to agentic execution
2. **The prize** → economics, leader/laggard gap, value at stake
3. **Where to play** → deployment patterns, use-case portfolio, bounded first, orchestration path
4. **How the system works** → loop, tools, data, memory, human oversight, policy guardrails
5. **How to scale** → phases, enabling rails, controls, value milestones

### 17.2 Default visual forms
- shift → transition bridge or staged evolution
- prize → chart-led proof page
- where-to-play → wedge, matrix, or choice architecture map
- system → closed-loop orbit or layered operating stack
- path-forward → transformation runway

### 17.3 Default executive implications
- Economic prize is real
- Readiness matters more than model novelty
- Bounded agents + orchestration are where near-term enterprise value emerges
- Governance, integration, operating model are gating factors
- Value should be sequenced, not pursued as disconnected pilots

### 17.4 Same structural logic applies to
Generative AI at scale · automation modernization · digital workforce strategy · enterprise op model for AI · future of work with autonomous systems.

### 17.5 Bookend logic for this topic family
Opener feels like an inflection point, not a generic title. Proof page carries the strongest chart. System page feels engineered. Final substantive page resolves into action. Closing/thank-you optional but echoes opener's motif.
